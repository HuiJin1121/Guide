<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use App\Models\Episode;
use App\Models\Movie;
use App\Traits\AppOrdered;
use Spatie\Activitylog\Traits\LogsActivity;
use Spatie\MediaLibrary\InteractsWithMedia;

class Sectionable extends Model
{
    use HasFactory, LogsActivity;

    protected $guarded = [];
    protected static $logAttributes = ["*"];
    protected static $logOnlyDirty = true;

}
