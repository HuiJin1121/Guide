<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use App\Models\Episode;
use App\Models\Season;
use App\Models\Movie;
use App\Traits\AppOrdered;
use Spatie\Activitylog\Traits\LogsActivity;
use Spatie\MediaLibrary\InteractsWithMedia;

class Section extends Model
{
    use HasFactory, LogsActivity, AppOrdered;

    protected $guarded = [];
    protected static $logAttributes = ["*"];
    protected static $logOnlyDirty = true;

    /**
     * Do not Change Below Value
     */
    const JUST_FOR_YOU_INDEX = 1;
    const CONTINUE_WATCHING_INDEX = 2;

    public function episodes()
    {
        return $this->morphedByMany(Episode::class, 'sectionable')->withPivot(['order','id']);
    }

    public function seasons()
    {
        return $this->morphedByMany(Season::class, 'sectionable')->withPivot(['order','id']);
    }

    public function movies()
    {
        return $this->morphedByMany(Movie::class, 'sectionable')->withPivot(['order','id']);
    }

}
