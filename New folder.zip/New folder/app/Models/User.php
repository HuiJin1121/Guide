<?php

namespace App\Models;

use App\Http\Middleware\ProfileSelectMiddleware;
use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;
use App\Models\Movie;
use App\Models\Episode;
use App\Models\Season;
use App\Models\Show;
use App\Models\Subscription;
use App\Models\Advertisement;
use App\Models\View;
use App\Models\Visit;
use App\Models\Setting;
use App\Models\Contribute;
use Spatie\Activitylog\Traits\LogsActivity;
use Spatie\Permission\Traits\HasRoles;
use Laravel\Cashier\Billable;
use App\Models\Withdraw;

class User extends Authenticatable
{
    use HasApiTokens, HasFactory, Notifiable, HasRoles, LogsActivity, Billable;

    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
    protected $guarded = [];

    protected static $logAttributes = ["*"];
    protected static $logOnlyDirty = true;

    /**
     * The attributes that should be hidden for serialization.
     *
     * @var array<int, string>
     */
    protected $hidden = [
        'password',
        'remember_token',
    ];

    /**
     * The attributes that should be cast.
     *
     * @var array<string, string>
     */
    protected $casts = [
        'email_verified_at' => 'datetime',
    ];

    public function p_subscriptions()
    {
        return $this->belongsToMany(Subscription::class,'p_subscriptions_user', 'user_id', 'p_subscription_id')->withPivot('expire_at', 'paypal_subscription_id', 'status', 'type');
    }

    public function movies()
    {
        return $this->hasMany(Movie::class);
    }
    public function shows()
    {
        return $this->hasMany(Show::class);
    }
    public function seasons()
    {
        return $this->hasMany(Season::class);
    }
    public function episodes()
    {
        return $this->hasMany(Episode::class);
    }
    public function visits()
    {
        return $this->hasMany(Visit::class);
    }
    public function views()
    {
        return $this->hasMany(View::class);
    }
    public function watchtimes()
    {
        return $this->hasMany(WatchTime::class);
    }
    public function profiles()
    {
        return $this->hasMany(\App\Models\Profile::class);
    }
    public function bookings()
    {
        return $this->hasMany(Booking::class);
    }
    public function orders()
    {
        return $this->hasMany(Order::class);
    }

    public function advertisements()
    {
        return $this->hasMany(Advertisement::class);
    }

    public function withdraws()
    {
        return $this->hasMany(Withdraw::class);
    }

    public function contributes(){
        return $this->hasMany(Contribute::class);
    }

    public function contMovies(){
        return $this->hasMany(Movie::class,'contribute_id');
    }

    public function contEpisodes(){
        return $this->hasMany(Episode::class,'contribute_id');
    }

    public function contShows(){
        return $this->hasMany(Show::class,'contribute_id');
    }

    public function getSuggestionVideos($profile_id) {

        $setting = Setting::firstOrFail();
        $suggest_video_amount = $setting->suggest_video_amount;

        $lazy_query = $profile_id == null ? View::query() : View::where('profile_id', $profile_id);
        $views = $lazy_query->where('user_id', $this->id)
        ->with([
            'movies.genres',
            'episodes.season.show.genres'
        ])->get();
        $user_id = $this->id;

        $genres = Genre::with([
            'movies' => function ($query) use ($user_id, $profile_id) {
                $query->whereHas('views', function ($query) use ($user_id, $profile_id) {
                    if(empty($profile_id))
                        $query->where('user_id', $user_id);
                    else 
                        $query->where('user_id', $user_id)->where('profile_id', $profile_id);
                })->withCount(['views' => function ($query) use ($user_id, $profile_id) {
                    if(empty($profile_id))
                        $query->where('user_id', $user_id);
                else 
                    $query->where('user_id', $user_id)->where('profile_id', $profile_id);
                }]);
            }
        ])->with([
            'shows' => function ($query) use ($user_id, $profile_id) {
                $query->whereHas('seasons', function ($query) use ($user_id, $profile_id) {
                    $query->whereHas('episodes', function ($query) use ($user_id, $profile_id) {
                        $query->whereHas('views', function ($query) use ($user_id, $profile_id) {
                            if(empty($profile_id))
                                $query->where('user_id',$user_id);
                            else 
                                $query->where('user_id', $user_id)->where('profile_id', $profile_id);
                        });
                    });
                })->with('seasons', function ($query) use ($user_id, $profile_id) {
                    $query->with('episodes', function ($query) use ($user_id, $profile_id) {
                        $query->withCount(['views' => function ($query) use ($user_id, $profile_id) {
                            if(empty($profile_id))
                                $query->where('user_id',$user_id);
                            else 
                                $query->where('user_id', $user_id)->where('profile_id', $profile_id);
                        }]);
                    });
                });
            }
        ])
        ->get();

        $genre_data = [];

        foreach($genres as $genre) {
            $movie_views_count = 0;
            $episode_views_count = 0;
            foreach($genre->movies as $movie) {
                $movie_views_count += $movie->views_count;
            }
            foreach($genre->shows as $show) {
                foreach($show->seasons as $season) {
                    foreach($season->episodes as $episode) {
                        $episode_views_count += $episode->views_count;
                    }
                }
            }
            $genre_data[$genre->id] = [
                "id" => $genre->id,
                "count"=>$movie_views_count + $episode_views_count
            ];
        }

        $genre_collect = collect($genre_data);

        $top_genres = $genre_collect->sortByDesc('count')->slice(0,3);

        $ids = $top_genres->pluck('id')->all();

        $movies = Movie::whereHas('genres', function ($query) use ($ids) {
            $query->whereIn('genres.id',$ids);
        })
        ->withCount('views')
        ->orderBy('created_at', 'desc')
        ->take($suggest_video_amount)
        ->get();

        $episodes = Episode::whereHas(
            'season', function ($query) use ($ids) {
                $query->whereHas('show', function ($query) use ($ids) {
                    $query->whereHas('genres', function ($query) use ($ids) {
                        $query->whereIn('genres.id', $ids);
                    });
                });
            }
        )
        ->with('season.show')
        ->withCount('views')
        ->orderBy('created_at', 'desc')
        ->take($suggest_video_amount)
        ->get();

        $suggest_movies = collect($movies);
        $suggest_episodes = collect($episodes);

        $videos = $suggest_movies->concat($suggest_episodes);

        return $videos->slice(0,$suggest_video_amount);
    }

    public function getWatchingVideos($profile_id) {
        $setting = Setting::firstOrFail();
        $suggest_video_amount = $setting->suggest_video_amount;
        $lazy_query = $profile_id == null ? WatchTime::query() : WatchTime::where('profile_id', $profile_id);

        $watch_time_movies = $lazy_query->where('user_id',$this->id)
        ->where('time','>=', 5)
        ->where('watchable_type','App\Models\Movie')
        ->orderBy('updated_at','desc')
        ->take($suggest_video_amount)
        ->get();

        $movies_id = $watch_time_movies->map(function ($item) {
            return $item->watchable_id;
        });

        $watch_time_episodes = $lazy_query->where('user_id',$this->id)
        ->where('time','>=', 5)
        ->where('watchable_type','App\Models\Episode')
        ->orderBy('updated_at','desc')
        ->take($suggest_video_amount)
        ->get();

        $episodes_id = $watch_time_episodes->map(function ($item) {
            return $item->watchable_id;
        });

        $movies = Movie::whereIn('id', $movies_id)->with('genres')->get();
        $episodes = Episode::whereIn('id', $episodes_id)->with('season.show.genres')->get();

        return $movies->concat($episodes)->sortBy('updated_at')->slice(0,$suggest_video_amount);
    }

}
