<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Contracts\Support\Renderable;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use App\Models\Section;
use App\Models\Sectionable;
use App\Models\Movie;
use App\Models\Episode;
use App\Models\Season;
use App\Models\Show;

class SectionController extends Controller
{

    public function index(Request $request) {
        $sections = Section::with(['movies','seasons'])->get();
        return view('admin.section.index',compact('sections'));
    }

    public function create(Request $request) {
        $sections = Section::all();
        return view('admin.section.create',compact('sections'));
    }

    public function show(Request $request, Section $section) {
        $section = Section::where('id', $section->id)->with([
            'seasons' => function ($query) {
                $query->with('show')->orderBy('order','asc');
            },
            'movies' => function ($query) {
                $query->orderBy('order','asc');
            }
        ])->firstOrFail();
        $videos = [];
        $movies = collect($section->movies);
        $seasons = collect($section->seasons);
        $videos = $movies->concat($seasons)->sortBy('pivot.order');
        return view('admin.section.show', compact('section','videos'));
    }

    public function edit(Request $request, Section $section) {
        $sections = Section::all();
        return view('admin.section.edit', compact('section','sections'));
    }

    public function store(Request $request) {
        $request->validate([
            'title' => 'required',
            'order_type' => 'required',
            'section_id' => 'required',
        ]);
        $title = $request->input('title');
        $order_type = $request->input('order_type');
        $section_id = $request->input('section_id');

        $sections = Section::all();

        $section_index = $sections->search(function ($item) use ($section_id) {
            return $item->id == $section_id; 
        });

        $section_count = $sections->count();

        $insert_from = "Start";

        if($section_count / 2 < $section_index) {
            $insert_from = "End";
        }

        $section_values = $sections->values();

        $order_option = -1;

        if($insert_from == "Start") {
            if($section_index == 0 && $order_type == "Before Section") {
                $order_option = $section_values->get(0)->order - 1;
            }
            else {
                $update_data = [];
                $max_index = $order_type == "Before Section" ? $section_index - 1 : $section_index;
                $order_option = $section_values->get($max_index)->order;
                for($index = 0 ; $index <= $max_index ; $index++){
                    $value = $section_values->get($index);
                    $new_order = $value->order - 1;
                    $new_title = $value->title;
                    array_push(
                        $update_data,
                        [
                            'id' => $value->id,
                            'order' => $new_order,
                            'title' => $new_title
                        ]
                    );
                }
                Section::upsert($update_data,'id');
            }
        }
        else {
            $order_option = 0;
            if($section_index == $section_count - 1 && $order_type == "After Section") {
                $order_option = $section_values->get($section_count - 1)->order + 1;
            }
            else {
                $update_data = [];
                $min_index = $order_type == "Before Section" ? $section_index : $section_index - 1;
                $order_option = $section_values->get($min_index)->order;
                for($index = $section_count - 1 ; $index >= $min_index ; $index--){
                    $value = $section_values->get($index);
                    $new_order = $value->order + 1;
                    $new_title = $value->title;
                    array_push(
                        $update_data,
                        [
                            'id' => $value->id,
                            'order' => $new_order,
                            'title' => $new_title
                        ]
                    );
                }
                Section::upsert($update_data,'id');
            }
        }

        Section::create(
            [
                'title' => $title,
                'order' => $order_option 
            ]
        );

        return redirect(route('sections.index'))->with('success', 'Section Created Successfully');
    }

    public function destroy(Request $request, Section $section) {
        Section::destroy([$section->id]);
        return redirect(route('sections.index'))->with('success', 'Section Deleted Successfully');
    }

    public function update(Request $request, Section $section) {
        $request->validate([
            'title' => 'required',
            'order_type' => 'required',
            'section_id' => 'required',
        ]);
        $title = $request->input('title');
        $order_type = $request->input('order_type');
        $section_id = $request->input('section_id');

        $sections = Section::all();

        $section_index = $sections->search(function ($item) use ($section_id) {
            return $item->id == $section_id; 
        });

        $section_count = $sections->count();

        $insert_from = "Start";

        if($section_count / 2 < $section_index) {
            $insert_from = "End";
        }

        $section_values = $sections->values();

        $order_option = -1;

        if($insert_from == "Start") {
            if($section_index == 0 && $order_type == "Before Section") {
                $order_option = $section_values->get(0)->order - 1;
            }
            else {
                $update_data = [];
                $max_index = $order_type == "Before Section" ? $section_index - 1 : $section_index;
                $order_option = $section_values->get($max_index)->order;
                for($index = 0 ; $index <= $max_index ; $index++){
                    $value = $section_values->get($index);
                    $new_order = $value->order - 1;
                    $new_title = $value->title;
                    array_push(
                        $update_data,
                        [
                            'id' => $value->id,
                            'order' => $new_order,
                            'title' => $new_title
                        ]
                    );
                }
                Section::upsert($update_data,'id');
            }
        }
        else {
            $order_option = 0;
            if($section_index == $section_count - 1 && $order_type == "After Section") {
                $order_option = $section_values->get($section_count - 1)->order + 1;
            }
            else {
                $update_data = [];
                $min_index = $order_type == "Before Section" ? $section_index : $section_index - 1;
                $order_option = $section_values->get($min_index)->order;
                for($index = $section_count - 1 ; $index >= $min_index ; $index--){
                    $value = $section_values->get($index);
                    $new_order = $value->order + 1;
                    $new_title = $value->title;
                    array_push(
                        $update_data,
                        [
                            'id' => $value->id,
                            'order' => $new_order,
                            'title' => $new_title
                        ]
                    );
                }
                
                Section::upsert($update_data,'id');
            }
        }

        Section::updateOrCreate(
            ['id' => $section->id],
            [
                'title' => $title,
                'order' => $order_option 
            ]
        );

        return redirect(route('sections.index'))->with('success', 'Section Updated Successfully');
    }

    public function change_order(Request $request, Section $section) {
        $request->validate([
            'other_id' => 'required'
        ]);
        $other_id = $request->input('other_id');
        $other_section = Section::findOrFail($other_id);
        $other_new_order= $section->order;
        $new_order= $other_section->order;

        Section::upsert([
            ['id'=>$other_id,
             'title' => $other_section->title,
             'order' => $other_new_order],
             ['id'=>$section->id,
             'title' => $section->title,
             'order' => $new_order],
        ],['id']);

        return redirect(route('sections.index'))->with('success', 'Section Order Changed Successfully');
    }

    public function store_video(Request $request, Section $section) {
        $request->validate([
            'video_type' => 'required',
            'order_type' => 'required',
        ]);

        $video_type = $request->input('video_type');
        $order_type = $request->input('order_type');
        $sectionable_id = $request->input('sectionable_id');
        $movie_id = $request->input('movie_id');
        $season_id = $request->input('season_id');
        
        $section_movies = collect($section->movies()->get());
        $section_seasons = collect($section->seasons()->get());

        if(!$section_movies->count() && !$section_seasons->count()){
            $order_option = 0;
            if($video_type == "movie") {
                $movie = Movie::find($movie_id);
                $section->movies()->attach($movie,['order' => $order_option]);
            }
            else {
                $season = Season::find($season_id);
                $section->seasons()->attach($season,['order' => $order_option]);
            }
            return redirect(route('sections.show',$section->id))->with('success', 'Section Video Created Successfully');
        }     

        $section_videos = $section_movies->concat($section_seasons)->sortBy('pivot.order');

        $sectionable_video_index = $section_videos->search(function ($item) use ($sectionable_id) {
            return $item->pivot->id == $sectionable_id; 
        });

        $section_videos_count = $section_videos->count();

        $insert_from = "Start";

        if($section_videos_count / 2 < $sectionable_video_index) {
            $insert_from = "End";
        }

        $section_video_values = $section_videos->values();

        $order_option = -1;

        if($insert_from == "Start") {
            if($sectionable_video_index == 0 && $order_type == "Before Video") {
                $order_option = $section_video_values->get(0)->pivot->order - 1;
            }
            else {
                $update_data = [];
                $max_index = $order_type == "Before Video" ? $sectionable_video_index - 1 : $sectionable_video_index;
                $order_option = $section_video_values->get($max_index)->pivot->order;
                for($index = 0 ; $index <= $max_index ; $index++){
                    $value = $section_video_values->get($index)->pivot;
                    $new_order = $value->order - 1;
                    array_push(
                        $update_data,
                        [
                            'id' => $value->id,
                            'order' => $new_order,
                            'sectionable_id' => $value->sectionable_id,
                            'sectionable_type' => $value->sectionable_type,
                            'section_id' => $value->section_id,
                        ]
                    );
                }
                Sectionable::upsert($update_data,'id');
            }
        }
        else {
            $order_option = 0;
            if($section_index == $section_count - 1 && $order_type == "After Video") {
                $order_option = $section_video_values->get($section_count - 1)->pivot->order + 1;
            }
            else {
                $update_data = [];
                $min_index = $order_type == "Before Video" ? $sectionable_video_index : $sectionable_video_index - 1;
                $order_option = $section_video_values->get($min_index)->pivot->order;
                for($index = $section_count - 1 ; $index >= $min_index ; $index--){
                    $value = $section_video_values->get($index)->pivot;
                    $new_order = $value->order + 1;
                    array_push(
                        $update_data,
                        [
                            'id' => $value->id,
                            'order' => $new_order,
                            'sectionable_id' => $value->sectionable_id,
                            'sectionable_type' => $value->sectionable_type,
                            'section_id' => $value->section_id,
                        ]
                    );
                }
                Sectionable::upsert($update_data,'id');
            }
        }

        $video = null;

        if($video_type == "movie") {
            $movie = Movie::find($movie_id);
            $section->movies()->attach($movie,['order' => $order_option]);
        }
        else {
            $season = Season::find($season_id);
            $section->seasons()->attach($season,['order' => $order_option]);
        }

        return redirect(route('sections.show',$section->id))->with('success', 'Section Video Created Successfully');
    }

    public function create_video(Request $request, Section $section) {
        $video_type = $request->input('video_type');
        $video_id = $request->input('video_id');
        if(empty($video_type)){
            $video_type = "movie";
        }
        $movies = Movie::all();
        $seasons = Season::with('show')->get();

        $section_movies = collect($section->movies()->get());
        $section_seasons = collect($section->seasons()->get());
        $section_videos = $section_movies->concat($section_seasons)->sortBy('pivot.order');

        return view('admin.section.create_video', 
            compact(
                'section',
                'movies',
                'seasons',
                'section_movies',
                'section_seasons',
                'section_videos',
                'video_type'
            )
        );
    }

    public function update_video(Request $request,Section $section , Sectionable $sectionable) {
        $request->validate([
            'other_id' => 'required'
        ]);
        $other_sectionable = Sectionable::find($request->other_id);
        $other_new_sectionable_order = $sectionable->order;
        $new_sectionable_order = $other_sectionable->order;
        Sectionable::upsert([
            [
                'id'=>$request->input('other_id'),
                'section_id' => $other_sectionable->section_id,
                'sectionable_id' => $other_sectionable->sectionable_id,
                'sectionable_type' => $other_sectionable->sectionable_type,
                'order' => $other_new_sectionable_order
            ],
            [
                'id'=>$sectionable->id,
                'section_id' => $sectionable->section_id,   
                'sectionable_id' => $sectionable->sectionable_id,
                'sectionable_type' => $sectionable->sectionable_type,
                'order' => $new_sectionable_order,
            ],
        ],['id']);
        return redirect(route('sections.show',$section->id))->with('success', 'Section Video Order Updated Successfully');
    }

    public function delete_video(Request $request, Section $section, Sectionable $sectionable) {
        Sectionable::destroy([$sectionable->id]);
        return redirect(route('sections.show',$section->id))->with('success', 'Section Video Deleted Successfully');
    }

}
