<?php

namespace App\Http\Controllers\Admin;

use App\Models\User;
use Illuminate\Contracts\Support\Renderable;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use App\Models\Movie;
use App\Models\Profile;
use App\Models\Episode;
use App\Models\View;
use App\Models\AdsView;
use App\Models\Setting;
use App\Models\MediaCategory;
use App\Models\Show;
use App\Models\Advertisement;
use Carbon\Carbon;
use Auth;
use DB;

class ViewController extends Controller
{
    /**
     * Display a listing of the resource.
     * @return Renderable
     */
    public function index(Request $request){
        $views = new View();
        $req_data = $request->all();

        if ($request->isMethod('post')) {
//            if ($type == 'user'){
//                $views = $views->where('user_id', $id);
//            }
            if (isset($req_data['profile_id'])){
                $id = $req_data['profile_id'];
                $views = $views->where('profile_id', $id);
            }
            if (isset($req_data['movie_id'])){
                $id = $req_data['movie_id'];
                $views = $views->where('viewable_id', $id);
            }
            if (isset($req_data['gender'])){
                $id = $req_data['gender'];
                $views = $views->whereHas('profile', function ($query) use ($id) {
                    $query->where('gender', $id);
                });
            }
            if (isset($req_data['age'])){
                $id = $req_data['age'];
                $views = $views->whereHas('profile', function ($query) use ($id) {
                    $query->where('age', $id);
                });
            }
            if (isset($req_data['from']) && isset($req_data['to'])){
                $from= $req_data['from'];
                $to = $req_data['to'];
                $views = $views->whereBetween('created_at', [$from, $to]);
            }
        }

        $visit_profiles = View::where('profile_id', '!=', null)->where('viewable_type', 'App\Models\Movie')->pluck('profile_id')->unique()->toArray();
        $profiles = Profile::wherein('id', $visit_profiles)->withSum('watchtimes','time')->get();

        $view_movies = View::where('viewable_id', '!=', null)->where('viewable_type', 'App\Models\Movie')->pluck('viewable_id')->unique()->toArray();
        $movies = Movie::wherein('id', $view_movies)->get();
        
        $total_view_count = $views->count();
        $total_watch_time = round($profiles->sum('watchtimes_sum_time'),0);

        $views = $views->where('viewable_type', 'App\Models\Movie')->paginate(15);

        return view(
            'admin.view.index', 
            compact(
                'views', 
                'profiles', 
                'movies', 
                'req_data',
                'total_view_count',
                'total_watch_time'
            )
        );
    }
    public function views_shows(Request $request){
        $views = new View();
        $req_data = $request->all();

        if ($request->isMethod('post')) {
//            if ($type == 'user'){
//                $views = $views->where('user_id', $id);
//            }
            if (isset($req_data['profile_id'])){
                $id = $req_data['profile_id'];
                $views = $views->where('profile_id', $id);
            }
            if (isset($req_data['episode_id'])){
                $id = $req_data['episode_id'];
                $views = $views->where('viewable_id', $id);
            }
            if (isset($req_data['gender'])){
                $id = $req_data['gender'];
                $views = $views->whereHas('profile', function ($query) use ($id) {
                    $query->where('gender', $id);
                });
            }
            if (isset($req_data['age'])){
                $id = $req_data['age'];
                $views = $views->whereHas('profile', function ($query) use ($id) {
                    $query->where('age', $id);
                });
            }
            if (isset($req_data['from']) && isset($req_data['to'])){
                $from= $req_data['from'];
                $to = $req_data['to'];
                $views = $views->whereBetween('created_at', [$from, $to]);
            }

        }

        $visit_profiles = View::where('profile_id', '!=', null)->where('viewable_type', 'App\Models\Show')->pluck('profile_id')->unique()->toArray();
        $profiles = Profile::wherein('id', $visit_profiles)->get();

        $view_episodes = View::where('viewable_id', '!=', null)->where('viewable_type', 'App\Models\Episode')->pluck('viewable_id')->unique()->toArray();
        $episodes = Episode::wherein('id', $view_episodes)->with('season.show')->withCount('views')->get();
        $views = $views->where('viewable_type', 'App\Models\Episode')->paginate(15);

        return view('admin.view.views_shows', compact('views', 'profiles', 'episodes', 'req_data'));
    }

    public function views_ads(Request $request){
        $views = new AdsView();
        $views = $views->paginate(15);
        $setting = Setting::first();
        $ad_length = isset($setting->ad_length) ? explode(',', $setting->ad_length) : [];
        $ad_price = isset($setting->ad_price) ? explode(',', $setting->ad_price) : [];
        $ad_special_price = isset($setting->ad_special_price) ? explode(',', $setting->ad_special_price) : [];
        $ad_image_price = $setting->ad_image_price;

        return view('admin.view.views_ads', compact('views', 'ad_length', 'ad_price', 'ad_special_price', 'ad_image_price'));
    }

    /**
     * Show the form for creating a new resource.
     * @return Renderable
     */
    public function create()
    {
        return view('admin.view.create');
    }

    /**
     * Store a newly created resource in storage.
     * @param Request $request
     * @return Renderable
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Show the specified resource.
     * @param int $id
     * @return Renderable
     */
    public function show($id)
    {
        return view('admin.view.show');
    }

    /**
     * Show the form for editing the specified resource.
     * @param int $id
     * @return Renderable
     */
    public function edit($id)
    {
        return view('admin.view.edit');
    }

    /**
     * Update the specified resource in storage.
     * @param Request $request
     * @param int $id
     * @return Renderable
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     * @param int $id
     * @return Renderable
     */
    public function destroy($id)
    {
        //
    }

    public function analytics($type = null, $id = null){

        $views = new View();
        if ($type == 'user'){
            $views = $views->where('user_id', $id);
        }
        if ($type == 'movie'){
            $views = $views->where('viewable_id', $id);
        }
        $from= null;
        $to_date = null;
        if ($type == 'date'){
            $from = $id;
            $to_date = $to;
            $views = $views->whereBetween('created_at', [$from, $to]);
        }
        $views = $views->where('viewable_type', 'App\Models\Movie')->paginate(15);
        return view('admin.view.index', compact('views', 'users', 'movies', 'id', 'from', 'to_date', 'type'));
    }

    public function views_videos(Request $request){
        
        $filter_p = $this->getPeriodParam($request);
        $media_categories = MediaCategory::all();

        $login_user = Auth::user();
        $canShowAllVideos = $login_user->can('view_all_videos');

        $movie_query = $canShowAllVideos ? new Movie() : Movie::whereHas('contribute',function ($query) use ($login_user){
            $query->where('user_id', $login_user->id);
        });

        $show_query = $canShowAllVideos ? new Show() : Show::whereHas('seasons', function ($query) use ($login_user){
            $query->whereHas('episodes', function ($query) use ($login_user){
                $query->whereHas('contribute',function ($query) use ($login_user){
                    $query->where('user_id', $login_user->id);
                });
            });
        });

        $data = array();

        $now = Carbon::now();
        $then = $this->getStartDay($request);

        foreach($media_categories as $media_category){
            $movies = $movie_query->where(
                'media_category_id', $media_category->id
            )->when(!$canShowAllVideos, function ($query) use ($login_user) {
                $query->whereHas('contributer', function ($query) use ($login_user){
                    $query->where('id', $login_user->id);
                });
            })->
            withCount(
                ['views' => function ($query) use ($then , $now) {
                    $query->whereBetween('created_at', [$then, $now]);
                }]
            )->withSum([
                'watchtimes' => function ($query) use ($then, $now){
                    $query->whereBetween('created_at', [$then, $now]);
                }
            ],'time')->get();

            $views_count = $movies->sum('views_count');
            $watch_time = $movies->sum('watchtimes_sum_time');

            $count = 0;

            if($movies != null)
                $count = $movies->count();

            $shows = $show_query->where('media_category_id', $media_category->id)->with(
                [
                    'seasons' => function ($query) use ($then, $now, $canShowAllVideos, $login_user){
                        $query->with(
                            [
                                'episodes' => function ($query) use ($then, $now, $canShowAllVideos, $login_user){
                                        $query->when(!$canShowAllVideos, function ($query) use ($login_user) {
                                            $query->whereHas('contributer',function ($query) use ($login_user){
                                                $query->where('id', $login_user->id);
                                            });
                                        })
                                        ->withCount([
                                            'views' => function ($query) use ($then, $now, $canShowAllVideos) {
                                                $query->whereBetween('created_at', [$then, $now]);
                                            }
                                        ])->withSum(
                                            [
                                                'watchtimes' => function ($query) use ($then, $now){
                                                    $query->whereBetween('created_at', [$then, $now]);
                                                }
                                            ],
                                            'time'
                                        );
                                }
                            ]
                        );
                    }
                ]
            )->get();

            $watch_time += $shows->sum(
                function($show){
                    return $show->seasons->sum(function ($season){
                        return $season->episodes->sum(
                            'watchtimes_sum_time'
                        );
                    });
                }
            );

            $views_count += $shows->sum(
                function($show){
                    return $show->seasons->sum(function ($season){
                        return $season->episodes->sum(
                            'views_count'
                        );
                    });
                }
            );

            if($shows != null)
                $count += $shows->count();

            $info = [
                "media_category" => $media_category,
                "count" => $count,
                "views_count" => $views_count,
                "watch_time" => $watch_time
            ];

            array_push(
                $data, $info
            );

        }

        return view(
            'admin.view.views_videos',
            compact(
                'media_categories',
                'filter_p',
                'data'
            )
        );
    }

    public function views_movies(Request $request){
        $start_day = $this->getStartDay($request);
        $end_day = Carbon::now();
        $filter_p = $this->getPeriodParam($request);

        $login_user = Auth::user();
        $canShowAllMovies = $login_user->hasRole('contributor');
        $isAdmin = $login_user->hasRole('admin') || $login_user->hasRole('super_admin');

        if(!$canShowAllMovies && !$isAdmin) $this->abortRoleError();


        $lazy_query = $isAdmin ? new Movie() : Movie::whereHas('contributer',function ($query) use($login_user){
            $query->where('id', $login_user->id);
        });

        $movies = $lazy_query->withSum(['watchtimes'=> function($query) use ($start_day, $end_day) {
            $query->whereBetween('created_at',[$start_day,$end_day]);
        }],'time')->withCount(
            ['views' => function ($query) use ($start_day, $end_day) {
                $query->whereBetween('created_at',[$start_day,$end_day]);
            }]
        )->get();

        return view(
            'admin.view.views_movies',
            compact(
                'movies',
                'filter_p'
            )
        );
    }

    public function views_movies_filter(Request $request){
        $movie_id = $request->query('movie_id');
        $filter_p = $this->getPeriodParam($request);

        $login_user = Auth::user();
        
        $canShowAllMovies = $login_user->hasRole('contributor');
        $isAdmin = $login_user->hasRole('super_admin') || $login_user->hasRole('admin');
        
        if(!$canShowAllMovies && !$isAdmin) abort(403);
        $lazy_query = $isAdmin ? new Movie() : Movie::whereHas(
            'contributer',function ($query) use ($login_user){
                $query->where('id', $login_user->id);
            }
        );

        $movies = $lazy_query->get();

        $now = Carbon::now();
        $then = $this->getStartDay($request);

        $movie = null;
        $current_views = null;
        $prev_views = null;
        $group_views = null;

        if($movie_id == null){
            $movie_id = $movies->first() == null ? -1 : $movies->first()->id;
        }

        if($movie_id != -1){


        $movie = $lazy_query->where('id',$movie_id)->firstOrFail();


        $prev_then = $this->getStartDay($request,$then);

        $current_views = $movie->views()->whereBetween('created_at',[$then,$now])->with('profile','user')->get();
        $prev_views = $movie->views()->whereBetween('created_at',[$prev_then, $then])->with('profile','user')->get();

        $group_views = $movie->views()->whereBetween(
            'created_at', [$then, $now]
        )->groupBy('date')
        ->distinct()
        ->orderBy('date', 'DESC')
        ->get(array(
            DB::raw('Date(created_at) as date'),
            DB::raw('COUNT(*) as "views"'),
        ));

        if($filter_p == "All History")
            $then = $movie->views()->whereBetween(
                'created_at', [$then, $now]
            )->min('created_at');
            $then = Carbon::parse($then);
        }

        return view(
            'admin.view.views_filter_movie',
            compact(
                'movie',
                'movies',
                'current_views',
                'prev_views',
                'movie_id',
                'filter_p',
                'group_views',
                'then',
                'now'
            )
        );
    }

    public function views_filter_tvshows(Request $request){
        $tvshow_id = $request->query('tvshow_id');
   
        $tvshow = null;
        $prev_tvshow = null;
        $filter_p = $this->getPeriodParam($request);
        
        $login_user = Auth::user();

        $isAdmin = $login_user->hasRole('super_admin') || $login_user->hasRole('admin');
        
        $canShowAllTVShow = $login_user->hasRole('contributor');

        if(!$canShowAllTVShow && !$isAdmin){
            abortRoleError();
        }

        $lazy_query = $isAdmin ? new Show() : Show::whereHas('seasons', function ($query) use ($login_user){
            $query->whereHas('episodes', function ($query) use ($login_user) {
                $query->whereHas('contributer',function ($query) use ($login_user){
                    $query->where('id',$login_user->id);
                });
            });
        })->orWherehas('contributer', function ($query) use ($login_user) {
            $query->where('id', $login_user->id);
        });
        
        $tvshows = $lazy_query->get();
        
        if($tvshow_id == null) {
            $tvshow_id = $tvshows->first() == null ? -1 : $tvshows->first()->id;
        }

        if($tvshow_id != -1){
        
        $tvshow = $lazy_query->where('id', $tvshow_id)->firstOrFail();

        $now = Carbon::now();
        $then = $this->getStartDay($request);
        $prev_then = $this->getStartDay($request, $then);

        $tvshow = Show::where('id',$tvshow_id)
        ->with(
            [
                'seasons' => function ($query) use ($then, $now) {
                    $query->with(
                        [
                            'episodes' => function ($query) use ($then, $now) {
                                $query-> with(
                                    [
                                        'views' => function ($query) use ($then, $now) {
                                                $query
                                                ->whereBetween('created_at',[$then, $now])
                                                ->with('profile');
                                        },
                                    ]
                                )->withSum(['watchtimes' => function ($query) use ($then, $now) {
                                    $query->whereBetween('created_at',[$then, $now]);
                                }],'time');
                            }
                        ]
                    );
                }
            ]
        )->first();

        $prev_tvshow = Show::where('id',$tvshow_id)
        ->whereBetween('created_at',[$prev_then,$then])
        ->with(
            [
                'seasons' => function ($query) use($then, $prev_then){
                    $query->with(
                        [
                            'episodes' => function ($query) use($then, $prev_then) {
                                $query-> with(
                                    [
                                        'views' => function ($query) use($then, $prev_then) {
                                                $query->whereBetween('created_at',[$prev_then,$then]);
                                        },
                                    ]
                                )->withSum(['watchtimes' => function ($query) use($then, $prev_then) {
                                    $query->whereBetween('created_at',[$prev_then,$then]);
                                }],'time');
                            }
                        ]
                    );
                }
            ]
        )->first();
        }

        return view(
            'admin.view.views_filter_tvshows',
            compact(
                'tvshows',
                'tvshow',
                'prev_tvshow',
                'tvshow_id',
                'filter_p'
            )
        );
    }

    public function views_tvshows(Request $request){

        $now = Carbon::now();
        $then = $this->getStartDay($request);
        $filter_p = $this->getPeriodParam($request);

        $login_user = Auth::user();
        $canShowTVShows = $login_user->hasRole('contributor');
        $isAdmin = $login_user->hasRole('super_admin') || $login_user->hasRole('admin');
        if(!$canShowTVShows && !$isAdmin) abort(403);

        $lazy_query = $isAdmin ? new Show() : Show::whereHas('seasons', function ($query) use ($login_user){
            $query->whereHas('episodes', function ($query) use ($login_user) {
                $query->whereHas('contributer',function ($query) use ($login_user){
                    $query->where('id', $login_user->id);
                });
            });
        })->orWhereHas('contributer', function ($query) use ($login_user) {
            $query->where('id', $login_user->id);
        });

        $tvshows = $lazy_query->with([
            'seasons' => function ($query) use($now, $then) {
                $query->with([
                    'episodes' => function ($query) use($now, $then) {
                        $query->withSum(['watchtimes'=>function ($query) use($then,$now) {
                            $query->whereBetween('created_at',[$then,$now]);
                        }],'time')->withCount(['views' => function ($query) use ($then, $now){
                            $query->whereBetween('created_at',[$then,$now]);
                        }]);
                    }
                ]);
            }
        ])->get();

        return view(
            'admin.view.views_tvshows',
            compact(
                'tvshows',
                'filter_p'
            )
        );
    }

    public function views_contributers(Request $request){

        $login_user = Auth::user();
        
        if(!$login_user->can('view_contributes')){
            abort(403);
        };
        
        $isAdmin = $login_user->hasRole('admin') || $login_user->hasRole('super_admin');

        $lazy_query = $isAdmin ? new User() : User::where('id', $login_user->id);
        
        $filter_p = $this->getPeriodParam($request);

        $now = Carbon::now();
        $then = $this->getStartDay($request);

        $contributers = $lazy_query->whereHas('roles',function ($query){
            $query->where('name', '!=', 'super_admin')->where('name', '!=', 'admin');
        })->whereHas('contributes',function ($query) {})
        ->with(['contMovies'=>function ($query) use ($then, $now) {
            $query->withSum(
                ['adsViews' => function ($query) use ($then, $now) {
                    $query->whereBetween('created_at',[$then, $now]);
                }],'cont_price'
            )->withCount(
                ['adsViews' => function ($query) use ($then, $now) {
                    $query->whereBetween('created_at',[$then, $now]);
                }]
            );
        }])
        ->with(['contEpisodes'=>function ($query) use ($then, $now) {
            $query->withSum(
                ['adsViews' => function ($query) use ($then, $now) {
                    $query->whereBetween('created_at',[$then, $now]);
                }],'cont_price'
            )->withCount(
                ['adsViews' => function ($query) use ($then, $now) {
                    $query->whereBetween('created_at',[$then, $now]);
                }]
            )->with('season.show');
        }])
        ->with(['contShows' => function ($query) use ($then, $now) {
            $query->with(['seasons' => function ($query) use ($then, $now) {
                $query->with(['episodes' => function($query) use ($then, $now){
                    $query->withSum(
                        ['adsViews' => function ($query) use ($then, $now) {
                            $query->whereBetween('created_at',[$then, $now]);
                        }],'cont_price'
                    )->withCount(
                        ['adsViews' => function ($query) use ($then, $now) {
                            $query->whereBetween('created_at',[$then, $now]);
                        }]
                    );
                }]);
            }]);
        }])
        ->get();

        return view(
            'admin.view.views_all_contributers',
            compact(
                'filter_p',
                'contributers',
            )
        );
    }

    public function views_filter_contributers(Request $request) {

        $login_user = Auth::user();

        $canShowAllContributes = $login_user->can('view_contributes');

        if(!$canShowAllContributes) $this->abortRoleError();

        $isAdmin = $login_user->hasRole('super_admin') || $login_user->hasRole('admin');

        $filter_p = $this->getPeriodParam($request);

        $user_id = $isAdmin ? $request->query('user_id') : $login_user->id;

        $lazy_query = ($isAdmin ? new User() : User::where('id', $login_user->id))->whereHas('roles',function ($query){
            $query->where('name','contributor');
        });

        $contributers = $lazy_query->get();

        if($contributers == null || $contributers->count() == 0)
            abort(404);

        if($isAdmin && $user_id == null)
            $user_id = $contributers->firstOrFail()->id;

        $now = Carbon::now();
        $then = $this->getStartDay($request);

        $contribute = User::where('id', $user_id)
        ->with(['contMovies'=>function ($query) use ($then, $now) {
            $query->withSum(
                ['adsViews' => function ($query) use ($then, $now) {
                    $query->whereBetween('created_at',[$then, $now]);
                }],'cont_price'
            )->withCount(['views' => function ($query) use ($then, $now) {
                $query->whereBetween('created_at',[$then, $now]);
            }])->withCount(['adsViews' => function ($query) use ($then, $now){
                $query->whereBetween('created_at',[$then, $now]);
            }]);
        }])
        ->with(['contEpisodes'=>function ($query) use ($then, $now) {
            $query->withSum(
                ['adsViews' => function ($query) use ($then, $now) {
                    $query->whereBetween('created_at',[$then, $now]);
                }],'cont_price'
            )->with('season.show')->withCount(['views' => function ($query) use ($then, $now) {
                $query->whereBetween('created_at',[$then, $now]);
            }])->withCount(['adsViews' => function ($query) use ($then, $now){
                $query->whereBetween('created_at',[$then, $now]);
            }]);
        }])
        ->with(['contShows' => function ($query) use ($then, $now) {
            $query->with(['seasons' => function ($query) use ($then, $now) {
                $query->with(['episodes' => function($query) use ($then, $now){
                    $query->withSum(
                        ['adsViews' => function ($query) use ($then, $now) {
                            $query->whereBetween('created_at',[$then, $now]);
                        }],'cont_price'
                    )->withCount(
                        ['adsViews' => function ($query) use ($then, $now) {
                            $query->whereBetween('created_at',[$then, $now]);
                        }]
                    );
                }]);
            }]);
        }])
        ->firstOrFail();

        return view(
            'admin.view.views_filter_contributers',
            compact(
                'filter_p',
                'user_id',
                'contributers',
                'contribute'
            )
        );
    }

    public function views_users(Request $request){
        
        $login_user = Auth::user();

        $canShowAllUsers = $login_user->can('view_all_users');

        $now = Carbon::now();
        $then = $this->getStartDay($request);

        /** Clone Carbon */
        $prev_then = $this->getStartDay($request,$then);

        $user_id = $request->query('user_id');
        $category = $request->query('category');

        $filter_p = $this->getPeriodParam($request);

        $user = null;

        $lazy_query = $canShowAllUsers ? new User() : User::where('id',$login_user->id);

        if($user_id == null) {
            $user_id = $lazy_query->first()->id;
        }
        $user_id = User::findOrFail($user_id)->id;

        if(!$canShowAllUsers && $user_id != $login_user->id){
            $this->abortRoleError();
        }

        $users = $lazy_query->get();

        if($category == null)
            $category = "Movie";
        if($category != "Movie" && $category != "Show") 
            $category = "Movie";

        $videos = null;

        if($category == "Movie"){
            $videos = Movie::with([
                'views' => function ($query) use ($now, $then, $user_id){
                    $query->where('user_id', $user_id)->whereBetween('created_at',[$then, $now])->with('profile');
                }
            ])->withSum(
                [
                    'watchtimes' => function ($query) use ($now, $then, $user_id) {
                        $query->where('user_id', $user_id)->whereBetween('created_at',[$then, $now]);
                    }
                ],'time'
            )->get();
        }
        else {
            $videos = Show::with(['seasons' => function($query) use ($now, $then, $user_id){
                $query->with(
                    [
                        'episodes' => function($query) use ($now, $then, $user_id){
                            $query->with(['views'=>function($query) use ($now, $then, $user_id) {
                                $query->where('user_id',$user_id)->whereBetween('created_at',[$then,$now])->with(
                                    'profile'
                                );
                            }])->withSum(
                                ['watchtimes' => function ($query) use($now, $then, $user_id) {
                                    $query->whereBetween('created_at',[$then,$now]);
                                }],'time'
                            );
                        }
                    ]
                );
            }])->get();
        }

        return view(
            'admin.view.views_users',
            compact(
                'category',
                'user_id',
                'users',
                'videos',
                'filter_p'
            )
        );

    }

    public function views_ads_all(Request $request){

        $login_user = Auth::user();
        
        $filter_p = $this->getPeriodParam($request);
        
        $now = Carbon::now();
        $then = $this->getStartDay($request);
        
        $canShowAllAds = $login_user->can('view_ads_views');

        if(!$canShowAllAds){
            abortRoleError();
        }

        $isAdmin = $login_user->hasRole('admin') || $login_user->hasRole('super_admin');

        $lazy_query = $isAdmin ? new Advertisement() : Advertisement::where('user_id', $login_user->id);

        $ads = $lazy_query->with([
            'adviews' => function ($query) use ($then, $now) {
                $query->whereBetween('created_at',[$then, $now]);
            },
            'user'
        ])->get();
        
        return view(
            'admin.view.views_ads_all',
            compact(
                'filter_p',
                'ads',
            )
        );

    }

    public function views_ads_filter(Request $request){
        $filter_p = $this->getPeriodParam($request);
        $ad_id = $request->query('ad_id');

        $login_user = Auth::user();

        $canShowAllAds = $login_user->can('view_ads_views');

        if(!$canShowAllAds){
            abortRoleError();
        }

        $isAdmin = $login_user->hasRole('admin') || $login_user->hasRole('super_admin');

        $lazy_query = $isAdmin ? new Advertisement() : Advertisement::where('user_id', $login_user->id);

        $now = Carbon::now();
        $then = $this->getStartDay($request);

        $ads = $lazy_query->get();
        
        if($ads == null || $ads->count() == 0){
            abort(404);            
        }
        else if($ad_id == null){
            $ad_id = $ads->first()->id; 
        }

        $ad = $lazy_query->findOrFail($ad_id);

        if(!$canShowAllAds && $ad->user->id != $login_user->id){
            $this->abortRoleError();
        }

        $ad = $lazy_query->where('id',$ad_id)->with(
            ['adViews' => function ($query) use($now, $then) {
                $query->whereBetween('created_at', [$then, $now]);
            }]
        )->first();

        $episodes = Episode::with([
            'adsViews' => function ($query) use ($ad_id, $then, $now) {
                $query->where('ads_id', $ad_id)->whereBetween('created_at',[$then, $now]);
            }, 'season'
        ])->get();

        $movies = Movie::with([
            'adsViews' => function ($query) use ($ad_id, $then, $now) {
                $query->where('ads_id', $ad_id)->whereBetween('created_at',[$then, $now]);
            }
        ])->get();

        $videos = $episodes->concat($movies);

        return view(
            'admin.view.views_filter_ads',
            compact(
                'ad_id',
                'ads',
                'filter_p',
                'videos',
                'ad',
            )
        );
    }

    public function views_filter_affiliates(Request $request){
        $now = Carbon::now();
        $then = $this->getStartDay($request);
        $filter_p = $this->getPeriodParam($request);

        $user_id = $request->query('user_id');

        $login_user = Auth::user();

        $isAdmin = $login_user->hasRole('admin') || $login_user->hasRole('super_admin');

        $canShow = $isAdmin || $login_user->hasRole('affiliate');
        $canShowOnlyMine = !$isAdmin && $login_user->hasRole('affiliate');

        if($canShowOnlyMine){
            $user_id = $login_user->id;
        }

        if($canShow){
            $lazy_query = $canShowOnlyMine ? User::where('id', $user_id) : new User();

            $affiliates = $lazy_query->whereHas('roles',function($query){
                $query->where('name','affiliate');
            })->get();

            if($affiliates == null || $affiliates->count() ==0 )
                abort(404);

            if($isAdmin && $user_id == null){
                $user_id = $affiliates->first()->id;
            }

            $users = User::whereBetween('created_at',[$then,$now])->where('ref_by',$user_id)->get();

            return view(
                'admin.view.views_filter_affiliate',
                compact(
                    'filter_p',
                    'affiliates',
                    'users',
                    'now',
                    'then',
                    'user_id'
                )
            );
        }
        else {
            $this->abortRoleError();
        }
    }
    
    public function views_affiliates(Request $request){
        $now = Carbon::now();
        $then = $this->getStartDay($request, $now);
        $filter_p = $this->getPeriodParam($request);

        $login_user = Auth::user();

        $isAdmin = $login_user->hasRole('admin') || $login_user->hasRole('super_admin');
        $isAffiliate = $login_user->hasRole('affiliate');

        if(!$isAdmin && !$isAffiliate)
            $this->abortRoleError();

        $lazy_query = $isAdmin ? new User() : User::where('id', $login_user->id);

        $affiliates = $lazy_query->whereHas('roles',function($query){
            $query->where('name','affiliate');
        })->get();

        return view(
            'admin.view.views_all_affiliates',
            compact(
                'affiliates',
                'filter_p',
                'then',
                'now',
            )
        );
    }
    
    public function getPeriodParam(Request $request){
        $day = $request->query('filter_p');
        if($day == "Weekly" || $day == "Monthly" || $day == "Yearly")
            return $day;
        return "All History";
    }

    public function getStartDay(Request $request, Carbon $carbon = null){
        $day = $request->query('filter_p');

        if($day == "Weekly")
            $day = 7;
        else if($day == "Monthly")
            $day = 30;
        else if($day == "Yearly")
            $day = 365;
        else {
            return Carbon::createFromTimestamp(0);
        }

        $p = $carbon == null ? Carbon::now() : $carbon->copy();

        return $p->subDays($day);
    }

    public function abortRoleError(){
        abort(403,"User Have Not Right Role");
    }

    public function isAdmin(){
        $user = Auth::user();
        return $user->hasRole('super_admin') || $user->hasRole('admin');
    }
}
