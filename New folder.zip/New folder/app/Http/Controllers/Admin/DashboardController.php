<?php

namespace App\Http\Controllers\Admin;

use Auth;
use App\Models\User;
use App\Models\Subscription;
use App\Models\Movie;
use App\Models\Show;
use App\Models\Visit;
use App\Models\View;
use App\Models\WatchTime;
use App\Models\Advertisement;
use App\Models\MediaCategory;
use App\Models\Episode;
use App\Models\Profile;
use Illuminate\Contracts\Support\Renderable;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Carbon\Carbon;
use DB;

class DashboardController extends Controller
{
    /**
     * Display a listing of the resource.
     * @return Renderable
     */
    public function index()
    {
        $request = request();

        $user = Auth::user();
        $affiliations=[];
        $referals=[];
        
        $now = Carbon::now();
        $prev_week_date = Carbon::now()->subDays(30);
        $prev_month_date = Carbon::now()->addMonth(-1);
        $prev_prev_week_date = Carbon::now()->subDays(60);

        $sports = [];
        $movies = [];
        $musics = [];
        $shows = [];

        $countries = [];
        $devices = [];
        $browsers = [];
        $my_vidoes = null;
        $my_ads = null;
        $my_affiliates = null;
        $my_earnings = 0;

        $users = [];
        $cancelled_users = [];
        $active_users = [];
        $have_no_subscription_users = [];
        
        $prev_users = [];
        $prev_cancelled_users = [];
        $prev_active_users = [];
        $prev_have_no_subscription_users = [];
        $my_withdraws = [];
        $media_data = [];

        $affiliate_earning = 0;
        $contribute_earning = 0;

        if($user->hasRole('super_admin') || $user->hasRole('admin')){

            $users = User::whereHas('roles', function ($query){
                $query->where('name','!=','super_admin');
            })->get();

            $users_query = User::whereHas('roles', function ($query){
                $query->where('name','!=','super_admin');
            });
            
            $users = $users_query->clone()->get();
            $active_users = $users_query->clone()->whereHas('p_subscriptions',function ($query){
                $query->where('expire_at','>', Carbon::now())->where('p_subscriptions_user.status','active');
            })->get();
            $cancelled_users = $users_query->clone()->whereHas('p_subscriptions')->doesntHave('p_subscriptions','and', function ($query){
                $query->where('expire_at','>', Carbon::now())->where('p_subscriptions_user.status','active');
            })->get();
            $have_no_subscription_users = $users_query->clone()->doesntHave('p_subscriptions')->get();

            $prev_users_query = User::whereHas('roles', function ($query){
                $query->where('name','!=','super_admin');
            })->where('created_at','<',$prev_week_date);

            $prev_users = $prev_users_query->clone()->get();
            $prev_cancelled_users = $prev_users_query->clone()->whereHas('p_subscriptions')->doesntHave('p_subscriptions','and', function ($query) use($prev_week_date) {
                $query->where('expire_at','>', Carbon::now())->where('p_subscriptions_user.status','active');
            })->get();
            $prev_active_users = $prev_users_query->clone()->whereHas('p_subscriptions',function ($query) use($prev_week_date) {
                $query->where('expire_at','>', $prev_week_date)->where('p_subscriptions_user.status','active');
            })->get();
            $prev_have_no_subscription_users = $prev_users_query->clone()->doesntHave('p_subscriptions')->get();

            $subscriptions = Subscription::all();

            $visit_data = Visit::whereBetween(
                'created_at', [$prev_month_date, $now]
            )->where('location','!=',null)
            ->groupBy('date', 'location')
            ->distinct()
            ->orderBy('date', 'ASC')
            ->orderBy('counts', 'DESC')
            ->get(array(
                DB::raw('Date(created_at) as date'),
                DB::raw('location'),
                DB::raw('COUNT(*) as "counts"'),
            ));

            $countries = new \stdClass();

            foreach($visit_data as $node){
                $key = $node->date;
                $country_name = $node->location;
                $counts = $node->counts;
                if(isset($countries->$key)){
                    $data = $countries->$key;
                    $data->$country_name = $counts;
                    $countries->$key = $data;
                }
                else {
                    $data = new \stdClass();
                    $data->$country_name = $counts;
                    $countries->$key = $data;
                }
            }

            $devices = Visit::whereBetween(
                'created_at', [$prev_month_date, $now]
            )->where('device' , '!=', null)
            ->where('device','!=', '0')
            ->groupBy('device')
            ->distinct()
            ->orderBy('counts', 'DESC')
            ->get(array(
                DB::raw('device'),
                DB::raw('COUNT(*) as "counts"'),
            ));


            $browsers = Visit::whereBetween(
                'created_at', [$prev_month_date, $now]
            )->where('browser' , '!=', null)
            ->where('browser','!=', '0')
            ->groupBy('browser')
            ->distinct()
            ->orderBy('counts', 'DESC')
            ->get(array(
                DB::raw('browser'),
                DB::raw('COUNT(*) as "counts"'),
            ));
            
            $movies = Movie::all();
            $shows = Show::with('seasons.episodes')->get();

            $videos = $movies->concat($shows);

            $media_categories = MediaCategory::all();

            foreach($media_categories as $media_category){
                $filter_videos_count = $videos->filter(function ($value) use ($media_category){
                    return $value->media_category_id == $media_category->id;
                })->count();
                $prev_filter_videos_count = $videos->filter(function ($value) use ($media_category, $prev_week_date) {
                    return $value->media_category_id == $media_category->id && $value->where('created_ad','<',$prev_week_date);
                })->count();
                $rise_percent = $prev_filter_videos_count == 0 ? 0 : ($prev_filter_videos_count * 100.0 / $filter_videos_count - 100);

                $data = new \stdClass();
                $data->name = $media_category->name;
                $data->rise_percent = $rise_percent;
                $data->count = $filter_videos_count;

                array_push($media_data, $data);
            }
            
        }
        else{
            $users = [];
            $subscriptions = [];
            $my_vidoes = [];
            $my_ads = $user->advertisements()->with(
                ['movies','episodes']
            )->get();

            $my_withdraws = $user->withdraws()->get();

            $avail_withdraws = $my_withdraws->filter(function ($value){
                return $value->status == 1;
            });

            $affiliate_earning = $avail_withdraws->filter(
                function ($value) {
                    return $value->withdraw_type == "affiliate";
                }
            )->sum('amount') + $user->a_cash;

            $contribute_earning = $avail_withdraws->filter(
                function ($value) {
                    return $value->withdraw_type == "contributor";
                }
            )->sum('amount') + $user->c_cash;

            $my_earnings = $affiliate_earning + $contribute_earning;            
        }

        if($user->hasRole('advertisements')){
            $my_ads = $user->advertisements()
            ->withCount('adviews')
            ->with('movies','episodes.season.show')
            ->get();
        }

        if($user->hasRole('affiliate')){
            $referals = User::where('ref_by', $user->id)->where('ref_by', '!=','')->with(['p_subscriptions' => function ($query){
                $query->select('p_subscriptions_user.status','p_subscriptions.name', 'expire_at');
            }])->get();
        }

        if($user->hasRole('contributor')){
            $movies = $user->contMovies()->withCount('views')->withCount('adsViews')->withSum('adsViews','cont_price')->get();
            $episodes = $user->contEpisodes()->withCount('views')->withCount('adsViews')->withSum('adsViews','cont_price')->with('season.show')->get();
            $shows = $user->contShows()->with(['seasons' => function ($query) {
                    $query->with(['episodes' => function ($query){
                        $query->withCount('views')->withCount('adsViews')->withSum('adsViews','cont_price');
                    }]);
                }])->get();
            $my_vidoes = new \stdClass();
            $my_vidoes->movies = $movies;
            $my_vidoes->episodes = $episodes;
            $my_vidoes->shows = $shows;
        }

        return view(
                'admin.dashboard.index', 
                compact(
                    'affiliations',
                    'referals',
                    'users',
                    'cancelled_users',
                    'active_users',
                    'have_no_subscription_users',
                    'prev_users',
                    'prev_cancelled_users',
                    'prev_active_users',
                    'prev_have_no_subscription_users',
                    'media_data',
                    'subscriptions',
                    'countries',
                    'browsers',
                    'devices',
                    'my_vidoes',
                    'my_ads',
                    'my_withdraws',
                    'my_earnings',
                    'contribute_earning',
                    'affiliate_earning',
                    'now',
                    'prev_month_date',
                    'prev_week_date'
                )
        );
    }

    /**
     * Show the form for creating a new resource.
     * @return Renderable
     */
    public function create()
    {
        return view('dashboard::create');
    }

    /**
     * Store a newly created resource in storage.
     * @param Request $request
     * @return Renderable
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Show the specified resource.
     * @param int $id
     * @return Renderable
     */
    public function show($id)
    {
        return view('dashboard::show');
    }

    /**
     * Show the form for editing the specified resource.
     * @param int $id
     * @return Renderable
     */
    public function edit($id)
    {
        return view('dashboard::edit');
    }

    /**
     * Update the specified resource in storage.
     * @param Request $request
     * @param int $id
     * @return Renderable
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     * @param int $id
     * @return Renderable
     */
    public function destroy($id)
    {
        //
    }
}
