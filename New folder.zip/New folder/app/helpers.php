<?php
    if (! function_exists('user_profile_helper')) {
        function user_profile_helper($user, $subscription){
            $maxProfiles = $subscription->number_of_profiles;
            $userProfiles = $user->profiles()->count();
            if ($userProfiles <= 0){
                $user->profiles()->create(['name' => 'Profile 1']);
            }elseif ($userProfiles > $maxProfiles){
                $difference = $userProfiles - $maxProfiles;
                App\Models\Profile::where('user_id', $user->id)->orderBy('id', 'desc')->limit($difference)->delete();
            }
        }
    }

    if (! function_exists('convert_sec_to_min')) {
        function convert_sec_to_min($sec){
            return floor($sec / 60.0);
        }
    }

    if (! function_exists('convert_to_finance_type')) {
        function convert_to_finance_type($value){
            return "$".floor($value *100) / 100;
        }
    }

    if (! function_exists('get_video_title')) {
        function get_video_title($video){
            if($video instanceof App\Models\Movie){
                return $video->title;
            }
            else if ($video instanceof App\Models\Episode){
                $season = null;
                $show = null;
                $episode_title = "";
                $season_title = "";
                $show_title = "";

                $episode_title = $video->title ?? "";

                if(!empty($video->season)) {
                    $season_title = $video->season->title ?? "";
                    if(!empty($video->season->show)){
                        $show_title = $video->season->show->title ?? "";
                    }
                }
                return $show_title . " | " . $season_title . " | " . $episode_title ;
            }
            else if ($video instanceof App\Models\Season){
                $season_title = "";
                $show_title = "";

                $season_title = $video->title ?? "";
                if(!empty($video->show)){
                    $show_title = $video->show->title ?? "";
                }
                return $show_title . " | " . $season_title;
            }
            
            return "";
        }

        if (! function_exists('get_video_route')) {
            function get_video_route($video){
                if($video instanceof App\Models\Movie){
                    return route('movie', $video->id);
                }
                else if ($video instanceof App\Models\Episode){
                    return route('season', $video->season->id);
                }
                else if ($video instanceof App\Models\Season){
                    return route('season', $video->id);
                }
                return "";
            }
        }

        if (! function_exists('get_video_genres')) {
            function get_video_genres($video){
                if($video instanceof App\Models\Movie){
                    return $video->genres;
                }
                else if ($video instanceof App\Models\Episode){
                    return $video->season->show->genres;
                }  
                else if ($video instanceof App\Models\Season){
                    return $video->show->genres;
                }
                else if ($video instanceof App\Models\Show){
                    return $video->genres;
                }  
                return null;
            }
        }
    }

?>