@extends('layouts.backend')

@section('content')
    <div class="nk-block">
        <div class="row g-gs">
                <div class="col-xxl-6 col-sm-12">
                    <div class="card">
                        <div class="nk-ecwg nk-ecwg6">
                            <div class="card-inner">
                                <div class="card-title-group">
                                    <div class="card-title">
                                        <h6 class="title">Contribute Videos</h6>
                                    </div>
                                </div>
                                @php
                                    $video_count = 0;
                                    if($contribute != null){
                                        $video_count = $contribute->contMovies->count();
                                        $video_count += $contribute->contEpisodes->count();
                                        foreach($contribute->contShows as $show){
                                            foreach($show->seasons as $season){
                                                $video_count += $season->episodes->count();
                                            }
                                        }
                                    }
                                @endphp
                                <div class="data">
                                    <div class="data-group">
                                        <div class="amount">Total: {{$video_count}}</div>
                                        <div class="nk-ecwg6-ck" style="height:90px !important">
                                        </div>
                                    </div>
                                </div>
                            </div><!-- .card-inner -->
                        </div><!-- .nk-ecwg -->
                    </div><!-- .card -->
                </div><!-- .col -->
                <div class="col-xxl-6 col-sm-12">
                    <div class="card">
                        <div class="nk-ecwg nk-ecwg6">
                            <div class="card-inner">
                                <div class="card-title-group">
                                    <div class="card-title">
                                        <h6 class="title">Contributor Wallet</h6>
                                    </div>
                                </div>
                                <div class="data">
                                    <div class="data-group">
                                        <div class="amount">Total: {{convert_to_finance_type($user->c_cash)}}</div>
                                        <div class="nk-ecwg6-ck" style="height:90px !important">
                                            
                                        </div>
                                    </div>
                                </div>
                            </div><!-- .card-inner -->
                        </div><!-- .nk-ecwg -->
                    </div><!-- .card -->
                </div><!-- .col -->
            </div>
        </div><!-- .nk-block -->
    </div>
    <br/>
    <div class="nk-block">
        <div class="card">
            <div class="card-aside-wrap">
                <div class="card-inner card-inner-lg">
                    <div class="nk-block-head nk-block-head-lg">
                        <div class="nk-block-between">
                            <div class="nk-block-head-content">
                                <h4 class="nk-block-title">My Contribute Earning</h4>
                            </div>
                            <div class="nk-block-head-content align-self-start d-lg-none">
                                <a href="#" class="toggle btn btn-icon btn-trigger mt-n1" data-target="userAside"><em class="icon ni ni-menu-alt-r"></em></a>
                            </div>
                        </div>
                    </div><!-- .nk-block-head -->
                        <div class="card card-preview">
                            <div class="card-inner">
                                <table class="datatable-init table">
                                    <thead>
                                        <tr>
                                            <th>Video Name</th>
                                            <th>Views</th>
                                            <th>Ad Plays</th>
                                            <th>Total Earning</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        @foreach ($contribute->contMovies as $movie)
                                            <tr>
                                                <td>{{ $movie->title }}</td>
                                                <td>{{ $movie->views_count ?? 0}}</td>
                                                <td>{{ $movie->ads_views_count ?? 0}}</td>
                                                <td>{{ convert_to_finance_type($movie->ads_views_sum_cont_price == null ? 0 : $movie->ads_views_sum_cont_price)}}</td>
                                            </tr>
                                        @endforeach
                                        @foreach ($contribute->contEpisodes as $episode)
                                            <tr>
                                                <td>{{ $episode->season->show->title." ".$episode->season->title." ".$episode->title }}</td>
                                                <td>{{ $episode->views_count ?? 0}}</td>
                                                <td>{{ $episode->ads_views_count ?? 0}}</td>
                                                <td>{{ convert_to_finance_type($episode->ads_views_sum_cont_price ? 0 : $movie->ads_views_sum_cont_price)}}</td>
                                            </tr>
                                        @endforeach
                                        @foreach ($contribute->contShows as $show)
                                            @foreach($show->seasons as $season)
                                                @foreach($season->episodes as $video)
                                                    <tr>
                                                        <td>{{ $show->title.' | '.$season->title.' | '.$video->title}}</td>
                                                        <td>{{ $video->views_count ?? 0}}</td>
                                                        <td>{{ $video->ads_views_count ?? 0}}</td>
                                                        <td>{{ convert_to_finance_type($video->ads_views_sum_cont_price == null ? 0 : $video->ads_views_sum_cont_price)}}</td>
                                                    </tr>
                                                @endforeach
                                            @endforeach
                                        @endforeach
                                    </tbody>
                                </table>
                            </div>
                        </div><!-- .card-preview -->
                </div>
                
                <!-- card-aside -->
            </div><!-- .card-aside-wrap -->
        </div><!-- .card -->
    </div><!-- .nk-block -->
@endsection
