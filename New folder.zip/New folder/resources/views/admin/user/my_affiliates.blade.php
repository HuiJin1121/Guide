@extends('layouts.backend')

@section('content')
    <div class="nk-block">
        <div class="row g-gs">
                <div class="col-xxl-6 col-sm-12">
                    <div class="card">
                        <div class="nk-ecwg nk-ecwg6">
                            <div class="card-inner">
                                <div class="card-title-group">
                                    <div class="card-title">
                                        <h6 class="title">Affiliations</h6>
                                    </div>
                                </div>
                                <div class="data">
                                    <div class="data-group">
                                        <div class="amount">Total: {{$refarals->count()}}</div>
                                        <div class="nk-ecwg6-ck" style="height:90px !important">
                                        </div>
                                    </div>
                                </div>
                            </div><!-- .card-inner -->
                        </div><!-- .nk-ecwg -->
                    </div><!-- .card -->
                </div><!-- .col -->
                <div class="col-xxl-6 col-sm-12">
                    <div class="card">
                        <div class="nk-ecwg nk-ecwg6">
                            <div class="card-inner">
                                <div class="card-title-group">
                                    <div class="card-title">
                                        <h6 class="title">Affiliate Wallet</h6>
                                    </div>
                                </div>
                                <div class="data">
                                    <div class="data-group">
                                        <div class="amount">Total: {{convert_to_finance_type($user->a_cash)}}</div>
                                        <div class="nk-ecwg6-ck" style="height:90px !important">
                                            
                                        </div>
                                    </div>
                                </div>
                            </div><!-- .card-inner -->
                        </div><!-- .nk-ecwg -->
                    </div><!-- .card -->
                </div><!-- .col -->
            </div>
        </div><!-- .nk-block -->
    </div>
    <br/>
    <div class="nk-block">
        <div class="card">
            <div class="card-aside-wrap">
                <div class="card-inner card-inner-lg">
                    <div class="nk-block-head nk-block-head-lg">
                        <div class="nk-block-between">
                            <div class="nk-block-head-content">
                                <h4 class="nk-block-title">My Referrals</h4>
                                <h4 class="nk-block-title">Referral Link: <u> {{route('register').'?ref='.\Illuminate\Support\Facades\Auth::id()}} </u></h4>
                            </div>
                            <div class="nk-block-head-content align-self-start d-lg-none">
                                <a href="#" class="toggle btn btn-icon btn-trigger mt-n1" data-target="userAside"><em class="icon ni ni-menu-alt-r"></em></a>
                            </div>
                        </div>
                    </div><!-- .nk-block-head -->
                        <div class="card card-preview">
                            <div class="card-inner">
                                <table class="datatable-init table">
                                    <thead>
                                        <tr>
                                            <th>email</th>
                                            <th>Joining Date</th>
                                            <th>Status</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        @foreach ($refarals as $referal)
                                            <tr>
                                                <td>{{ $referal->email }}</td>
                                                <td>{{ date_format( $referal->created_at,"Y M d") }}</td>
                                                <td>
                                                        @php
                                                            $status = "No Subscription";
                                                            $clsName = "badge-success";
                                                            if($referal->p_subscriptions->count() != 0){
                                                                foreach($referal->p_subscriptions as $p_subscription){
                                                                    if($p_subscription->status == "active" && $p_subscription->expire_at > \Carbon\Carbon::now()){
                                                                        @endphp
                                                                        <span class="badge {{$clsName}}">{{$p_subscription->name}}</span>
                                                                        @php
                                                                    }
                                                                    else {
                                                                        @endphp
                                                                        <span class="badge">{{$p_subscription->name}}</span>
                                                                        @php
                                                                    }
                                                                }

                                                            }
                                                            else {
                                                                    @endphp
                                                                    <span class="badge badge-info">No Subscription</span>
                                                                    @php
                                                            }
                                                        @endphp
                                                </td>
                                            </tr>
                                        @endforeach
                                    </tbody>
                                </table>
                            </div>
                        </div><!-- .card-preview -->
                </div>
                
                <!-- card-aside -->
            </div><!-- .card-aside-wrap -->
        </div><!-- .card -->
    </div><!-- .nk-block -->
@endsection
