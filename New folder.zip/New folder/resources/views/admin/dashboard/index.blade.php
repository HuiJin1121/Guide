@extends('layouts.backend')
@section('css')
    <style>
        .modal {
        padding: 0 !important; // override inline padding-right added from js
        }
        .modal .modal-dialog {
        width: 100%;
        max-width: none;
        margin: 0;
        }
        .modal .modal-content {
        height: 100%;
        border: 0;
        border-radius: 0;
        }
        .modal .modal-body {
        overflow-y: auto;
        }
    </style>
@endsection
@section('content')

    @php
        $user = \Illuminate\Support\Facades\Auth::user();
    @endphp

    @if($user->hasRole('super_admin') || $user->hasRole('admin'))
    
    <style>
        .my-custom-chart-class {
            background-color: #ff0000;
            border: 1px solid red;
        }
    </style>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
    <script src="https://code.highcharts.com/highcharts.js"></script>
    <script type="text/javascript">

        document.onready = drawChart;

        function drawChart() {
            drawBrowsersChart();
            drawCountriesChart();
        }
        
        function drawCountriesChart(){

            @if($countries == null)
                return;
            @else 
                var chart = {
                    type: 'areaspline'	  
                };
                var title = {
                    text: ''   
                }; 
                var subtitle = {
                    style: {
                        position: 'absolute',
                        right: '0px',
                        bottom: '10px'
                    }
                };
                var legend = {
                    enabled : false
                };
                var xAxis = {
                    type: 'datetime',
                };
                var yAxis = {
                    allowDecimals:false,
                    title: {
                        text: null
                    }
                };
                var global = {
                    useUTC: false
                };
                var tooltip = {
                    shared: true,
                    useHTML: true,
                    formatter: function () {
                        var value = Highcharts.dateFormat('%Y-%b-%e',
                                          new Date(this.x));
                        var index = getDayDiff(
                                new Date(this.series.xData[0]),
                                new Date(this.x),
                        );
                        var country_node = countries_detail[index];

                        if(country_node.length == 0){
                            return '<table style="border: 1px solid #ccc; padding: 5px; width: 150px;">'
                                + '<thead>'
                                + '<tr><td>No Country on ' + value
                                +"</td></tr>"
                                + "</thead>"
                                + "<table>";
                        }

                        var html = '<table style="border: 1px solid #ccc; padding: 5px; width: 150px;">';
                        html += '<thead>';
                        html += "<caption>" + country_node.length + " Countries" + " on " + value +"</caption>"
                        html += '<tr><td>Country</td><td>Visit Count</td></tr>';
                        html += "</thead>";
                        html += "<tbody>";
                        for(var i = 0 ; i < country_node.length ; i++){
                            var point = country_node[i];
                            html += '<tr>';
                            html += '<td>' + point.country_name + '</td>';
                            html += '<td>' + point.counts + '</td>';
                            html += '</tr>';
                        }

                        html += '</tbody>';
                        html += '</table>';
                        return html;
                    },
                };

                var credits = {
                    enabled: false
                }
                var plotOptions = {
                    areaspline: {
                        fillOpacity: 0.5
                    },        
                    series: {
                            pointStart: Date.UTC(
                                {{$prev_month_date->year}},
                                {{$prev_month_date->month - 1}},
                                {{$prev_month_date->day}},
                            ),
                            pointIntervalUnit: 'day'
                    }
                };

                @php
                    $array_size = $now->diffInDays($prev_month_date);
                @endphp

                var data = Array({{$array_size}} + 1).fill(0);
                var countries_detail = Array({{$array_size}} + 1).fill([]);

                @php
                    foreach($countries as $date_str => $country_info){
                        $date = \Carbon\Carbon::parse($date_str);
                        $index = $prev_month_date->diffInDays($date);
                        @endphp
                            data[{{$index}}] = {{count((array)$country_info)}};
                            var node = [
                                    @php
                                        foreach($country_info as $country_name => $counts){
                                            @endphp
                                                {
                                                    counts : "{{$counts}}",
                                                    country_name : "{{$country_name}}",                                                
                                                },
                                            @php
                                        }
                                    @endphp
                                ];
                            countries_detail[{{$index}}] = node;
                        @php
                    }
                @endphp

                var series = [
                    {
                        name: 'Views',
                        data
                    }, 
                ];

                var json = {};
                json.chart = chart; 
                json.title = title;
                json.subtitle = subtitle; 
                json.xAxis = xAxis;
                json.yAxis = yAxis;
                json.legend = legend;
                json.plotOptions = plotOptions;
                json.credits = credits;
                json.series = series;
                json.tooltip = tooltip;

                Highcharts.chart('countries_chart',json,null);

                @endif
        }

        function drawBrowsersChart(){

            var browsers = [
                @foreach($browsers as $data)
                        {
                            name:'{{$data->browser}}',
                            count:{{$data->counts}}
                        },
                @endforeach
            ];

            var colors = Highcharts.getOptions().colors;

            var browserData = [];
            var i, j;
            var dataLen = browsers.length;
            
            // Build the data arrays
            for (i = 0; i < dataLen; i += 1) {
               // add browser data
               browserData.push({
                  name: browsers[i].name,
                  y: browsers[i].count,
                  color: colors[i]
               });
            }

            var chart = {
               type: 'pie'
            };
            var title = {
               text:""
            };      
            var yAxis = {
               title: {
                  text: 'Total percent'
               }
            };
            var credits = {
                enabled: false
            };
            var tooltip = {
               valueSuffix: ''
            };
            var plotOptions = {
               pie: {
                  allowPointSelect: true,
                  cursor: 'pointer',
                  dataLabels: {
                     enabled: false           
                  },
                  showInLegend: true
               }
            };
            var series = [
               {
                  name: 'Browsers',
                  data: browserData,
                  size:'80%',
                  innerSize: '60%',
                  
                  dataLabels: {
                     formatter: function () {
                        return this.y > 5 ? this.point.name : null;
                     },
                     color: 'white',
                     distance: -30
                  }
               }, 
            ];     
            var legend = {
                labelFormat: '{name} ({percentage:.1f}%)',
            };
               
            var json = {};   
            json.chart = chart; 
            json.yAxis = yAxis;
            json.credits = credits;
            json.title = title;        
            json.tooltip = tooltip;  
            json.series = series;
            json.legend = legend;
            json.plotOptions = plotOptions;

            Highcharts.chart('browsers_chart',json,null);
        }

        function getDayDiff(from, to){
            const diffTime = Math.abs(to - from);
            const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24)); 
            return diffDays;
        }

    </script>

    <div class="nk-block-head nk-block-head-sm">
        <div class="nk-block-between">
            <div class="nk-block-head-content">
                <h4 class="nk-block-title page-title">Admin Dashboard</h4>
            </div><!-- .nk-block-head-content -->
        </div><!-- .nk-block-between -->
    </div><!-- .nk-block-head -->
    @else
    <div class="nk-block-head nk-block-head-sm">
        <div class="nk-block-between">
            <div class="nk-block-head-content">
                <h4 class="nk-block-title page-title">Welcome {{$user->name}}</h4>
            </div><!-- .nk-block-head-content -->
        </div><!-- .nk-block-between -->
    </div><!-- .nk-block-head -->
    @endif

    @if($user->hasRole('super_admin') || $user->hasRole('admin'))
        <div class="nk-block">
            <div class="row g-gs">
                <div class="col-xxl-3 col-sm-6">
                    <div class="card">
                        <div class="nk-ecwg nk-ecwg6">
                            <div class="card-inner">
                                <div class="card-title-group">
                                    <div class="card-title">
                                        <h6 class="title">Total Users</h6>
                                    </div>
                                </div>
                                <div class="data">
                                    @php
                                        $count = $users->count();
                                        $prev_count = $prev_users->count();
                                        $rise_percent = $prev_count == 0 ? 0 : round($count * 100.0 / $prev_count,2) - 100; 
                                    @endphp
                                    <div class="data-group">
                                        <div class="amount">{{$count}}</div>
                                        <div class="nk-ecwg6-ck" style="height:90px !important">
                                        </div>
                                    </div>
                                    <!-- <div class="info"><span class="change up text-danger"><em class="icon ni ni-arrow-long-up"></em>4.63%</span><span> vs. last week</span></div> -->
                                    <div class="info">
                                        <span class="change
                                                        @if($rise_percent < 0) text-warning change
                                                        @else change up text-danger
                                                        @endif">
                                            <em class="icon ni 
                                                        @if($rise_percent < 0) ni-arrow-long-down
                                                        @else ni-arrow-long-up
                                                        @endif">
                                            </em>
                                            {{$rise_percent}}%
                                        </span>
                                        <span> vs. last week</span>
                                    </div>
                                </div>
                            </div><!-- .card-inner -->
                        </div><!-- .nk-ecwg -->
                    </div><!-- .card -->
                </div><!-- .col -->
                <div class="col-xxl-3 col-sm-6">
                    <div class="card">
                        <div class="nk-ecwg nk-ecwg6">
                            <div class="card-inner">
                                <div class="card-title-group">
                                    <div class="card-title">
                                        <h6 class="title">Active Users</h6>
                                    </div>
                                </div>
                                <div class="data">
                                    @php
                                        $count = $active_users->count();
                                        $prev_count = $prev_active_users->count();
                                        $rise_percent = $prev_count == 0 ? 0 : round($count * 100.0 / $prev_count,2) - 100; 
                                    @endphp
                                    <div class="data-group">
                                        <div class="amount">{{$count}}</div>
                                        <div class="nk-ecwg6-ck" style="height:90px !important">
                                            
                                        </div>
                                    </div>
                                    <div class="info">
                                        <span class="change
                                                        @if($rise_percent < 0) text-warning
                                                        @else change up text-danger
                                                        @endif">
                                            <em class="icon ni 
                                                        @if($rise_percent < 0) ni-arrow-long-down
                                                        @else ni-arrow-long-up
                                                        @endif">
                                            </em>
                                            {{$rise_percent}}%
                                        </span>
                                        <span> vs. last week</span>
                                    </div>
                                </div>
                            </div><!-- .card-inner -->
                        </div><!-- .nk-ecwg -->
                    </div><!-- .card -->
                </div><!-- .col -->
                <div class="col-xxl-3 col-sm-6">
                    <div class="card">
                        <div class="nk-ecwg nk-ecwg6">
                            <div class="card-inner">
                                <div class="card-title-group">
                                    <div class="card-title">
                                        <h6 class="title">Cancelled Users</h6>
                                    </div>
                                </div>
                                <div class="data">
                                    @php
                                        $count = $cancelled_users->count();
                                        $prev_count = $prev_cancelled_users->count();
                                        $rise_percent = $prev_count == 0 ? 0 : round($count * 100.0 / $prev_count,2) - 100; 
                                    @endphp
                                    <div class="data-group">
                                        <div class="amount">{{$count}}</div>
                                        <div class="nk-ecwg6-ck" style="height:90px !important">
                                        </div>
                                    </div>
                                    <div class="info">
                                        <span class="change
                                                        @if($rise_percent < 0) text-warning
                                                        @else change up text-danger
                                                        @endif">
                                            <em class="icon ni 
                                                        @if($rise_percent < 0) ni-arrow-long-down
                                                        @else ni-arrow-long-up
                                                        @endif">
                                            </em>
                                            {{$rise_percent}}%
                                        </span>
                                        <span> vs. last week</span>
                                    </div>
                                </div>
                            </div><!-- .card-inner -->
                        </div><!-- .nk-ecwg -->
                    </div><!-- .card -->
                </div><!-- .col -->
                <div class="col-xxl-3 col-sm-6">
                    <div class="card">
                        <div class="nk-ecwg nk-ecwg6">
                            <div class="card-inner">
                                <div class="card-title-group">
                                    <div class="card-title">
                                        <h6 class="title">No Subscription Users</h6>
                                    </div>
                                </div>
                                <div class="data">
                                    @php
                                        $count = $have_no_subscription_users->count();
                                        $prev_count = $prev_have_no_subscription_users->count();
                                        $rise_percent = $prev_count == 0 ? 0 : round($count * 100.0 / $prev_count,2) - 100; 
                                    @endphp
                                    <div class="data-group">
                                        <div class="amount">{{$count}}</div>
                                        <div class="nk-ecwg6-ck" style="height:90px !important">
                                        </div>
                                    </div>
                                    <div class="info">
                                        <span class="change
                                                        @if($rise_percent < 0) text-warning
                                                        @else change up text-danger
                                                        @endif">
                                            <em class="icon ni 
                                                        @if($rise_percent < 0) ni-arrow-long-down
                                                        @else ni-arrow-long-up
                                                        @endif">
                                            </em>
                                            {{$rise_percent}}%
                                        </span>
                                        <span> vs. last week</span>
                                    </div>
                                </div>
                            </div><!-- .card-inner -->
                        </div><!-- .nk-ecwg -->
                    </div><!-- .card -->
                </div><!-- .col -->

                @foreach($media_data as $data)
                <div class="col-xxl-3 col-sm-6">
                    <div class="card">
                        <div class="nk-ecwg nk-ecwg6">
                            <div class="card-inner">
                                <div class="card-title-group">
                                    <div class="card-title">
                                        <h6 class="title">Total {{$data->name}}</h6>
                                    </div>
                                </div>
                                <div class="data">
                                    <div class="data-group">
                                        <div class="amount">{{$data->count}}</div>
                                        <div class="nk-ecwg6-ck" style="height:90px !important">
                                            
                                        </div>
                                    </div>
                                    <div class="info">
                                        <span class="change
                                                        @if($data->rise_percent < 0) text-warning
                                                        @else change up text-danger
                                                        @endif">
                                            <em class="icon ni 
                                                        @if($data->rise_percent < 0) ni-arrow-long-down
                                                        @else ni-arrow-long-up
                                                        @endif">
                                            </em>
                                            {{$data->rise_percent}}%
                                        </span>
                                        <span> vs. last week</span>
                                    </div>
                                </div>
                            </div><!-- .card-inner -->
                        </div><!-- .nk-ecwg -->
                    </div><!-- .card -->
                </div><!-- .col -->
                @endforeach

            </div><!-- .nk-block -->
            <br>

            <div class="nk-block">
                <h4 class="nk-block-title">Visits</h4>
                <div class="row g-gs">
                    <div class="col-xxl-6 col-sm-12">
                        <div class="card">
                            <div class="nk-ecwg nk-ecwg6">
                                <div class="card-inner">
                                    <div class="card-title-group">
                                        <div class="card-title">
                                            <h6 class="title">Countries</h6>
                                        </div>
                                    </div>
                                    <div class="data">
                                        <div class="data-group">
                                            <div 
                                                class="col-12"
                                                id="countries_chart" 
                                                style="height: 400px;"
                                                ></div>
                                        </div>
                                    </div>
                                </div><!-- .card-inner -->
                            </div><!-- .nk-ecwg -->
                        </div><!-- .card -->
                    </div><!-- .col -->

                    <div class="col-xxl-3 col-sm-6">
                        <div class="card">
                            <div class="nk-ecwg nk-ecwg6">
                                <div class="card-inner">
                                    <div class="card-title-group">
                                        <div class="card-title">
                                            <h6 class="title">Browsers</h6>
                                        </div>
                                    </div>
                                    <div class="data">
                                        <div class="data-group">
                                            <div class="col-xl-12" 
                                                id="browsers_chart" 
                                                style="height: 400px;"
                                                >
                                            </div>
                                        </div>
                                        <!-- <div class="info"><span class="change up text-danger"><em class="icon ni ni-arrow-long-up"></em>4.63%</span><span> vs. last week</span></div> -->
                                    </div>
                                </div><!-- .card-inner -->
                            </div><!-- .nk-ecwg -->
                        </div><!-- .card -->
                    </div><!-- .col -->

                    <div class="col-xxl-3 col-sm-6">
                        <div class="card">
                            <div class="nk-ecwg nk-ecwg6">
                                <div class="card-inner">
                                    <div class="card-title-group">
                                        <div class="card-title">
                                            <h6 class="title">Devices</h6>
                                        </div>
                                    </div>
                                    <div class="data">
                                    <div class="data-group">
                                    <div class="card card-preview">
                                        <div class="card-inner">
                                            <table class="datatable-init table">
                                                <thead>
                                                    <tr>
                                                        <th>Name</th>
                                                        <th>Counts</th>
                                                        <th>Icon</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    @foreach ($devices as $data)
                                                        <tr>
                                                            <td>{{ $data->device }}</td>
                                                            <td>{{ $data->counts ?? 0}}</td>
                                                            <td>Icon</td>
                                                        </tr>
                                                    @endforeach
                                                </tbody>
                                            </table>
                                        </div>
                                    </div><!-- .card-preview -->
                                        </div>
                                        <!-- <div class="info"><span class="change up text-danger"><em class="icon ni ni-arrow-long-up"></em>4.63%</span><span> vs. last week</span></div> -->
                                    </div>
                                </div><!-- .card-inner -->
                            </div><!-- .nk-ecwg -->
                        </div><!-- .card -->
                    </div><!-- .col -->
                </div>
            </div><!-- .nk-block -->

        </div>
    @endif

    @if(!$user->hasRole('super_admin') && !$user->hasRole('admin'))
        <div class="row g-gs">
            <div class="col-xxl-3 col-sm-6">
                <div class="card">
                    <div class="nk-ecwg nk-ecwg6">
                        <div class="card-inner">
                            <div class="card-title-group">
                                <div class="card-title">
                                    <h6 class="title">Total Videos</h6>
                                </div>
                            </div>
                            <div class="data">
                                <div class="data-group">
                                    @php 
                                        $video_count = 0;
                                        if($my_vidoes != null){
                                            $video_count += $my_vidoes->movies->count();
                                            $video_count += $my_vidoes->episodes->count();
                                            foreach($my_vidoes->shows as $show){
                                                foreach($show->seasons as $season){
                                                    $video_count += $season->episodes->count();
                                                }                                                    
                                            }
                                        }
                                    @endphp
                                    <div class="amount">{{$video_count}}</div>
                                    <div class="nk-ecwg6-ck" style="height:90px !important">
                                    </div>
                                </div>
                                <div class="info">
                                </div>
                            </div>
                        </div><!-- .card-inner -->
                    </div><!-- .nk-ecwg -->
                </div><!-- .card -->
            </div><!-- .col -->
            <div class="col-xxl-3 col-sm-6">
                <div class="card">
                    <div class="nk-ecwg nk-ecwg6">
                        <div class="card-inner">
                            <div class="card-title-group">
                                <div class="card-title">
                                    <h6 class="title">Active Ads</h6>
                                </div>
                            </div>
                            <div class="data">

                                <div class="data-group">
                                    <div class="amount">{{$my_ads->filter(function ($value){
                                        return $value->status == 1;
                                    })->count()}}</div>
                                    <div class="nk-ecwg6-ck" style="height:90px !important">
                                        
                                    </div>
                                </div>
                                <div class="info">
                                </div>
                            </div>
                        </div><!-- .card-inner -->
                    </div><!-- .nk-ecwg -->
                </div><!-- .card -->
            </div><!-- .col -->
            <div class="col-xxl-3 col-sm-6">
                <div class="card">
                    <div class="nk-ecwg nk-ecwg6">
                        <div class="card-inner">
                            <div class="card-title-group">
                                <div class="card-title">
                                    <h6 class="title">Total Affiliates</h6>
                                </div>
                            </div>
                            <div class="data">
                                <div class="data-group">
                                    <div class="amount">{{$referals == null ? 0 : $referals->count()}}</div>
                                    <div class="nk-ecwg6-ck" style="height:90px !important">

                                    </div>
                                </div>
                                <div class="info">
                                </div>
                            </div>
                        </div><!-- .card-inner -->
                    </div><!-- .nk-ecwg -->
                </div><!-- .card -->
            </div><!-- .col -->
            <div class="col-xxl-3 col-sm-6">
                <div class="card">
                    <div class="nk-ecwg nk-ecwg6">
                        <div class="card-inner">
                            <div class="card-title-group">
                                <div class="card-title">
                                    <h6 class="title">Total Earnings</h6>
                                </div>
                            </div>
                            <div class="data">
                                <div class="data-group">
                                    <div class="amount">
                                        ${{floor($my_earnings * 100) / 100}}
                                    </div>
                                    <div style="height:90px !important">
                                        <div>
                                            <div>
                                            <span class="change up text-danger">
                                                Contributor:{{convert_to_finance_type($contribute_earning)}}
                                            </span>
                                            </div>
                                            <div>
                                            <span class="change up text-danger">
                                                Affiliate:{{convert_to_finance_type($affiliate_earning)}}
                                            </span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div><!-- .card-inner -->
                    </div><!-- .nk-ecwg -->
                </div><!-- .card -->
            </div><!-- .col -->

        </div><!-- .nk-block -->
        <br>
        @if($user->hasRole('affiliate'))
        <div class="nk-block">
            <div class="card">
                <div class="card-aside-wrap">
                    <div class="card-inner card-inner-lg">
                        <div class="nk-block-head nk-block-head-lg">
                            <div class="nk-block-between">
                                <div class="nk-block-head-content">
                                    <h4 class="nk-block-title">My Referrals</h4>
                                    <h4 class="nk-block-title">Referral Link: <u> {{route('register').'?ref='.\Illuminate\Support\Facades\Auth::id()}} </u></h4>
                                </div>
                                <div class="nk-block-head-content align-self-start d-lg-none">
                                    <a href="#" class="toggle btn btn-icon btn-trigger mt-n1" data-target="userAside"><em class="icon ni ni-menu-alt-r"></em></a>
                                </div>
                            </div>
                        </div><!-- .nk-block-head -->
                        {{-- {{ $refarals }} --}}
                            {{-- referal data table --}}
                            <div class="card card-preview">
                                <div class="card-inner">
                                    <table class="datatable-init table">
                                        <thead>
                                            <tr>
                                                <th>Email</th>
                                                <th>Joining Date</th>
                                                <th>Status</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            @foreach ($referals as $referal)
                                                <tr>
                                                    <td>{{ $referal->email }}</td>
                                                    <td>{{ date_format( $referal->created_at,"Y M d") }}</td>
                                                    <td>
                                                        @php
                                                            $status = "No Subscription";
                                                            $clsName = "badge-success";
                                                            if($referal->p_subscriptions->count() != 0){
                                                                foreach($referal->p_subscriptions as $p_subscription){
                                                                    if($p_subscription->status == "active" && $p_subscription->expire_at > \Carbon\Carbon::now()){
                                                                        @endphp
                                                                        <span class="badge {{$clsName}}">{{$p_subscription->name}}</span>
                                                                        @php
                                                                    }
                                                                    else {
                                                                        @endphp
                                                                        <span class="badge">{{$p_subscription->name}}</span>
                                                                        @php
                                                                    }
                                                                }

                                                            }
                                                            else {
                                                                    @endphp
                                                                    <span class="badge badge-info">{{$status}}</span>
                                                                    @php
                                                            }
                                                        @endphp
                                                        
                                                    </td>
                                                </tr>
                                            @endforeach
                                        </tbody>
                                    </table>
                                </div>
                            </div><!-- .card-preview -->
                    </div>
                </div><!-- .card-aside-wrap -->
            </div><!-- .card -->
        </div><!-- .nk-block -->
        <br/>
        @endif

        @if($user->hasRole('advertisements'))
        <div class="nk-block">
            <div class="card">
                <div class="card-aside-wrap">
                    <div class="card-inner card-inner-lg">
                        <div class="nk-block-head nk-block-head-lg">
                            <div class="nk-block-between">
                                <div class="nk-block-head-content">
                                    <h4 class="nk-block-title">My Ads</h4>
                                </div>
                                <div class="nk-block-head-content align-self-start d-lg-none">
                                    <a href="#" class="toggle btn btn-icon btn-trigger mt-n1" data-target="userAside"><em class="icon ni ni-menu-alt-r"></em></a>
                                </div>
                            </div>
                        </div><!-- .nk-block-head -->
                            <div class="card card-preview">
                                <div class="card-inner">
                                    <table class="datatable-init table">
                                        <thead>
                                            <tr>
                                                <th>Ad Name</th>
                                                <th>Type</th>
                                                <th>Views</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            @foreach ($my_ads as $ad)
                                                <tr>
                                                    <td>{{ $ad->name }}</td>
                                                    <td>{{ $ad->type }}</td>
                                                    <td>{{ $ad->adviews->count() }}</td>
                                                </tr>
                                            @endforeach
                                        </tbody>
                                    </table>
                                </div>
                            </div><!-- .card-preview -->
                    </div>
                </div><!-- .card-aside-wrap -->
            </div><!-- .card -->
        </div><!-- .nk-block -->
        <br/>
        @endif

        @if($user->hasRole('contributor'))
        <div class="nk-block">
            <div class="card">
                <div class="card-aside-wrap">
                    <div class="card-inner card-inner-lg">
                        <div class="nk-block-head nk-block-head-lg">
                            <div class="nk-block-between">
                                <div class="nk-block-head-content">
                                    <h4 class="nk-block-title">My Videos</h4>
                                </div>
                                <div class="nk-block-head-content align-self-start d-lg-none">
                                    <a href="#" class="toggle btn btn-icon btn-trigger mt-n1" data-target="userAside"><em class="icon ni ni-menu-alt-r"></em></a>
                                </div>
                            </div>
                        </div><!-- .nk-block-head -->
                        <div class="card card-preview">
                            <div class="card-inner">
                                <table class="datatable-init table">
                                    <thead>
                                        <tr>
                                            <th>Name</th>
                                            <th>Views</th>
                                            <th>Earning</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        @foreach ($my_vidoes->movies as $video)
                                            <tr>
                                                <td>{{ $video->title}}</td>
                                                <td>{{ $video->views_count ?? 0}}</td>
                                                <td>{{ convert_to_finance_type($video->ads_views_sum_cont_price == null ? 0 : $video->ads_views_sum_cont_price)}}</td>
                                            </tr>
                                        @endforeach
                                        @foreach ($my_vidoes->episodes as $video)
                                            <tr>
                                                <td>{{ $video->season->show->title.' | '.$video->season->title.' | '.$video->title}}</td>
                                                <td>{{ $video->views_count ?? 0}}</td>
                                                <td>{{ convert_to_finance_type($video->ads_views_sum_cont_price == null ? 0 :$video->ads_views_sum_cont_price)}}</td>
                                            </tr>
                                        @endforeach
                                        @foreach ($my_vidoes->shows as $show)
                                            @foreach($show->seasons as $season)
                                                @foreach($season->episodes as $video)
                                                    <tr>
                                                        <td>{{ $show->title.' | '.$season->title.' | '.$video->title}}</td>
                                                        <td>{{ $video->views_count ?? 0}}</td>
                                                        <td>{{ convert_to_finance_type($video->ads_views_sum_cont_price == null ? 0 : $video->ads_views_sum_cont_price)}}</td>
                                                    </tr>
                                                @endforeach
                                            @endforeach
                                        @endforeach
                                    </tbody>
                                </table>
                            </div>
                        </div><!-- .card-preview -->
                    </div>
                </div><!-- .card-aside-wrap -->
            </div><!-- .card -->
        </div><!-- .nk-block -->
        <br/>
        @endif
    @endif
@endsection

@section('script')
    <script type="text/javascript">
        $(window).on('load', function() {
            $('#myModal').modal('show');
        });
        $("#myModal").modal({"backdrop": "static", keyboard: false});
    </script>
    <link type="text/css" href="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/themes/south-street/jquery-ui.css" rel="stylesheet">
    <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js"></script>
    <script type="text/javascript" src="{{url('/')}}/jquery.signature.js"></script>
    <script type="text/javascript" src="{{url('/')}}/jquery.ui.touch-punch.min.js"></script>

    <link rel="stylesheet" type="text/css" href="{{url('/')}}/jquery.signature.css">

@endsection