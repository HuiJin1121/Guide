@extends('layouts.backend')
@section('content')
<div class="nk-block">
        <div class="nk-block-head">
            <div class="nk-block-head-content">
                <h4 class="nk-block-title">{{$section->title}}
                    <a href="{{route('sections.create_video', $section->id)}}" class="btn btn-outline-success float-right"><em class="icon ni ni-plus"></em><span>Add Section Video</span></a>
                </h4>
                <div class="nk-block-des">
                    <!-- <p>Using the most basic table markup, here’s how <code class="code-class">.table</code> based tables look by default.</p> -->
                </div>
            </div>
        </div>
        <div class="card">
            <div class="card-aside-wrap">
                <div class="card-inner card-inner-lg">
                        <div class="card card-preview">
                            <div class="card-inner">
                            <table class="table">
                                    <thead>
                                        <tr>
                                            <th class="nk-tb-col">Title</th>
                                            <th class="nk-tb-col nk-tb-col-tools text-right">Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        @php
                                            $video_values = $videos->values();
                                        @endphp
                                        @foreach($videos as $video)
                                            <tr class="nk-tb-item">
                                                <td>
                                                    {{get_video_title($video)}}
                                                </td>
                                                <td class="nk-tb-col">
                                                    <ul class="nk-tb-actions gx-1">
                                                            @if(!$loop->first)
                                                            @php
                                                                $prev_index = $loop->index - 1;
                                                                $prev_item = $video_values->get($prev_index);
                                                            @endphp
                                                            <li class="nk-tb-action-hidden">
                                                                    <form action="{{ route('sections.update_video',[$section->id, $video->pivot->id]) }}" method="POST">
                                                                        @csrf
                                                                        @method('PUT')
                                                                        <input type = "hidden" value = "{{$prev_item->pivot->id}}" name="other_id"/>
                                                                        <button type="submit" class="btn btn-sm btn-outline-warning d-inline-flex" data-toggle="tooltip" data-placement="top" title="Up">
                                                                            <em class="icon ni ni-arrow-up"></em>
                                                                            <span>Up</span>
                                                                        </button>
                                                                    </form>
                                                            </li>
                                                            @endif
                                                            @if(!$loop->last)
                                                            @php
                                                                $next_index = $loop->index + 1;
                                                                $next_item = $video_values->get($next_index);
                                                            @endphp
                                                            <li class="nk-tb-action-hidden">
                                                                <form action="{{ route('sections.update_video',[$section->id, $video->pivot->id]) }}" method="POST">
                                                                    @csrf
                                                                    @method('PUT')
                                                                    <input type = "hidden" value = "{{$next_item->pivot->id}}" name="other_id"/>
                                                                    <button type="submit" class="btn btn-sm btn-outline-info d-inline-flex" data-toggle="tooltip" data-placement="top" title="Down">
                                                                        <em class="icon ni ni-arrow-down"></em>
                                                                        <span>Down</span>
                                                                    </button>
                                                                </form>
                                                            </li>
                                                            @endif
                                                            <li class="nk-tb-action-hidden">
                                                                <form action="{{ route('sections.delete_video',[$section->id, $video->pivot->id]) }}" method="POST">
                                                                    @csrf
                                                                    @method('DELETE')
                                                                    <button type="submit" onclick="return confirm('Are you sure you want to delete this item?')" class="btn btn-sm btn-outline-danger d-inline-flex" data-toggle="tooltip" data-placement="top" title="Delete">
                                                                        <em class="icon ni ni-trash"></em>
                                                                        <span>Delete</span>
                                                                    </button>
                                                                </form>
                                                            </li>
                                                    </ul>
                                            </td>
                                            </tr>
                                        @endforeach   
                                    </tbody>
                                </table>
                            </div>
                        </div>
                </div>
            </div>
        </div>
    </div><!-- .nk-block -->

@endsection