@extends('layouts.backend')
@section('content')
<div class="nk-block">
        <div class="nk-block-head">
            <div class="nk-block-head-content">
                <h4 class="nk-block-title">All Sections
                    <a href="{{route('sections.create')}}" class="btn btn-outline-success float-right"><em class="icon ni ni-plus"></em><span>Add Section </span></a>
                </h4>
                <div class="nk-block-des">
                    <!-- <p>Using the most basic table markup, here’s how <code class="code-class">.table</code> based tables look by default.</p> -->
                </div>
            </div>
        </div>
        <div class="card">
            <div class="card-aside-wrap">
                <div class="card-inner card-inner-lg">
                        <div class="card card-preview">
                            <div class="card-inner">
                            <table class="table">
                                    <thead>
                                        <tr>
                                            <th class="nk-tb-col">Title</th>
                                            <th class="nk-tb-col">Item Count</th>
                                            <th class="nk-tb-col nk-tb-col-tools text-right">Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        @foreach($sections as $section)
                                            <tr class="nk-tb-item">
                                                @php
                                                    $count = $section->movies->count() + $section->episodes->count() 
                                                @endphp
                                                <td>
                                                    @if($section->id != \App\Models\Section::JUST_FOR_YOU_INDEX && $section->id != \App\Models\Section::CONTINUE_WATCHING_INDEX)
                                                        <a href="{{route('sections.show',$section->id)}}">{{$section->title}}</a>
                                                    @else
                                                        {{$section->title}}
                                                    @endif
                                                </td>
                                                <td>{{$count}}</td>
                                                <td class="nk-tb-col">
                                                    <ul class="nk-tb-actions gx-1">
                                                            @if(!$loop->first)
                                                            @php
                                                                $prev_index = $loop->index - 1;
                                                                $prev_item = $sections[$prev_index];
                                                            @endphp
                                                            <li class="nk-tb-action-hidden">
                                                                    <form action="{{ route('sections.change_order',$section->id) }}" method="POST">
                                                                        @csrf
                                                                        @method('patch')
                                                                        <input type = "hidden" value = "{{$prev_item->id}}" name="other_id"/>
                                                                        <button type="submit" class="btn btn-sm btn-outline-warning d-inline-flex" data-toggle="tooltip" data-placement="top" title="Up">
                                                                            <em class="icon ni ni-arrow-up"></em>
                                                                            <span>Up</span>
                                                                        </button>
                                                                    </form>
                                                            </li>
                                                            @endif
                                                            @if(!$loop->last)
                                                            @php
                                                                $next_index = $loop->index + 1;
                                                                $next_item = $sections[$next_index];
                                                            @endphp
                                                            <li class="nk-tb-action-hidden">
                                                                <form action="{{ route('sections.change_order',$section->id) }}" method="POST">
                                                                    @csrf
                                                                    @method('PATCH')
                                                                    <input type = "hidden" value = "{{$next_item->id}}" name="other_id"/>
                                                                    <button type="submit" class="btn btn-sm btn-outline-info d-inline-flex" data-toggle="tooltip" data-placement="top" title="Down">
                                                                        <em class="icon ni ni-arrow-down"></em>
                                                                        <span>Down</span>
                                                                    </button>
                                                                </form>
                                                            </li>
                                                            @endif
                                                            <li class="nk-tb-action-hidden">
                                                                <a href="{{route('sections.edit', $section->id)}}" class="btn btn-sm btn-outline-success d-inline-flex"><em class="icon ni ni-expand"></em><span>Edit</span></a>
                                                            </li>
                                                            <li class="nk-tb-action-hidden">
                                                                <form action="{{ route('sections.destroy',$section->id) }}" method="POST">
                                                                    @csrf
                                                                    @method('DELETE')
                                                                    <button type="submit" onclick="return confirm('Are you sure you want to delete this item?')" class="btn btn-sm btn-outline-danger d-inline-flex" data-toggle="tooltip" data-placement="top" title="Delete">
                                                                        <em class="icon ni ni-trash"></em>
                                                                        <span>Delete</span>
                                                                    </button>
                                                                </form>
                                                            </li>
                                                    </ul>
                                            </td>
                                            </tr>
                                        @endforeach   
                                    </tbody>
                                </table>
                            </div>
                        </div>
                </div>
            </div>
        </div>
    </div><!-- .nk-block -->

@endsection