@extends('layouts.backend')

@section('content')
    <div class="nk-content">
        <div class="container-fluid">
            <div class="nk-block nk-block-lg">
                <div class="nk-block-between mb-2">
                    <div class="nk-block-head-content">
                        <h3 class="nk-block-title page-title">Add Section Video</h3>
                    </div><!-- .nk-block-head-content -->
                    <div class="nk-block-head-content">
                        <div class="toggle-wrap nk-block-tools-toggle">
                            <a href="#" class="btn btn-icon btn-trigger toggle-expand mr-n1" data-target="pageMenu"><em class="icon ni ni-more-v"></em></a>
                            <div class="toggle-expand-content" data-content="pageMenu">
                            </div>
                        </div>
                    </div><!-- .nk-block-head-content -->
                </div><!-- .nk-block-between -->
                <div class="card">
                    <div class="card-inner">

                        <form method="POST" id="main_form" action="{{ route('sections.store_video',$section->id) }}" id="form" >
                            @csrf
                            <div class="row">
                                <div class="col-6 form-group">
                                    <label class="form-label" for="video_type">Video Type</label>
                                    <div class="form-control-wrap">
                                        <select class="form-select" id="video_type" name="video_type">
                                            <option value="movie" @if(old('video_type') == 'movie') selected @endif>Movie</option>
                                            <option value="show" @if(old('video_type') == 'show') selected @endif>Show</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-6 form-group" id="season_group">
                                    <label class="form-label" for="season_id">Seasons</label>
                                    <div class="form-control-wrap">
                                        <select class="form-select" id="season_id" name="season_id">

                                            @foreach($seasons as $video)
                                                @if(
                                                    $section_seasons->search(
                                                        function ($item) use ($video) {
                                                            return $item->id === $video->id;
                                                        }
                                                    ) === false
                                                )
                                                    <option value="{{$video->id}}" @if(old('video_id') == $video->id) selected @endif>{{get_video_title($video)}}</option>
                                                @endif
                                            @endforeach
                                        </select>
                                    </div>
                                </div>
                                <div class="col-6 form-group" id="movie_group">
                                    <label class="form-label" for="movie_id">Movie</label>
                                    <div class="form-control-wrap">
                                        <select class="form-select" id="movie_id" name="movie_id">
                                            @foreach($movies as $video)
                                                @php
                                                    $video_title = "";
                                                    if($video instanceof \App\Models\Movie) {
                                                        $video_title = $video->title;
                                                    }   
                                                    else if($video instanceof \App\Models\Episode) {
                                                        $episode_title = $video->title;
                                                        $season_title = "";
                                                        $show_title = "";
                                                        $season = null;
                                                        $show = null;
                                                        $season = $video->season;
                                                        if($season){
                                                            $season_title = $season->title ?? "";
                                                            $show = $season->show;
                                                            if($show) {
                                                                $show_title =$show->title ?? "";
                                                            }
                                                        }
                                                        $video_title = $show_title . " | " . $season_title . " | ".$episode_title;
                                                    }
                                                @endphp
                                                @if($section_movies->search(function ($item) use ($video) {
                                                    return $item->id == $video->id;  
                                                }) === false)
                                                <option value="{{$video->id}}" @if(old('video_id') == $video->id) selected @endif>{{$video_title}}</option>
                                                @endif
                                            @endforeach
                                        </select>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="row">
                                <div class="col-6 form-group">
                                    <label class="form-label" for="order_type">Order Type</label>
                                    <div class="form-control-wrap">
                                        <select class="form-select" id="order_type" name="order_type">
                                            <option value="Before Video" @if(old('order_type') == 'Before Video') selected @endif>Before Video</option>
                                            <option value="After Video" @if(old('order_type') == 'After Video') selected @endif>After Video</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-6 form-group">
                                    <label class="form-label" for="sectionable_id">Target Video</label>
                                    <div class="form-control-wrap">
                                        <select class="form-select" id="sectionable_id" name="sectionable_id">
                                            @foreach($section_videos as $video)
                                                @php
                                                    $video_title = "";
                                                    if($video instanceof \App\Models\Movie) {
                                                        $video_title = $video->title;
                                                    }   
                                                    else if($video instanceof \App\Models\Episode) {
                                                        $episode_title = $video->title;
                                                        $season_title = "";
                                                        $show_title = "";
                                                        $season = null;
                                                        $show = null;
                                                        $season = $video->season;
                                                        if($season){
                                                            $season_title = $season->title ?? "";
                                                            $show = $season->show;
                                                            if($show) {
                                                                $show_title =$show->title ?? "";
                                                            }
                                                        }
                                                        $video_title = $show_title . " | " . $season_title . " | ".$episode_title;
                                                    }
                                                @endphp
                                                <option value="{{$video->pivot->id}}" @if(old('video_id') == $video->id) selected @endif>{{$video_title}}</option>
                                            @endforeach
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <button type="submit" class="btn btn-primary float-right">Submit</button>
                        </form>
                    </div>
                </div><!-- card -->

            </div>
        </div>
@endsection
@section('script')
    <script>
        @php
            $now_video_type = old('video_type') ?? $video_type ?? "movie";
            if($video_type == "movie") {
                @endphp
                $('#movie_group').removeClass('d-none');
                $('#season_group').addClass('d-none');
                @php
            }
            else {
                @endphp
                $('#season_group').removeClass('d-none');
                $('#movie_group').addClass('d-none');
                @php
            }
        @endphp
        $('#video_type').on('change', function(){
            if ($(this).val() == 'movie' ) {
                $('#movie_group').removeClass('d-none');
                $('#season_group').addClass('d-none');
            } else {
                $('#season_group').removeClass('d-none');
                $('#movie_group').addClass('d-none');
            }
        })
    </script>
@endsection