@extends('layouts.backend')

@section('content')

            <script>
                    function filterChange(){
                        document.getElementById('select_form').submit();
                    }
            </script>

            <div class="nk-block">
                <h4 class="nk-block-title">All Video Analysis</h4>
                <form action="{{ route('views.videos.all') }}" id="select_form">   
                    <div class="row g-gs">
                        <div class="col-3">
                            <div class="form-group">
                                <label class="form-label" for="filter_p">Time Range</label>
                                <div class="form-control-wrap">
                                    <select class="form-select" id="filter_p" onchange="filterChange()" name="filter_p">
                                        <option value="All History" @if($filter_p == "All History") selected @endif>All History</option>
                                        <option value="Yearly" @if($filter_p == "Yearly") selected @endif>Yearly</option>
                                        <option value="Monthly" @if($filter_p == "Monthly") selected @endif>Monthly</option>
                                        <option value="Weekly" @if($filter_p == "Weekly") selected @endif>Weekly</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                    </div>
                </form>
                <div class="row g-gs">
                    <div class="col-xxl-12 col-sm-12">
                        <div class="card">
                            <div class="nk-ecwg nk-ecwg6">
                                <div class="card-inner">
                                    <div class="card-title-group">
                                        <div class="card-title">
                                            <h6 class="title">Video Analysis</h6>
                                        </div>
                                    </div>
                                    <div class="data">
                                        <div class="data-group">
                                            <div
                                                class="col-12"
                                                id="all_video_chart" 
                                                style="height: 400px;"
                                                >
                                                <table class="nowrap nk-tb-list is-separate datatable no-footer" data-auto-responsive="false" id="DataTables_Table_2" role="grid" aria-describedby="DataTables_Table_2_info">
                                                    <thead>
                                                        <tr class="nk-tb-item nk-tb-head" role="row">
                                                            <th class="nk-tb-col sorting" >Categories</th>
                                                            <th class="nk-tb-col  sorting" >Total</th>
                                                            <th class="nk-tb-col  sorting" >Views</th>
                                                            <th class="nk-tb-col  sorting" >Watch Minutes</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        @foreach($data as $node)
                                                            <tr class="nk-tb-item odd">
                                                                <td class="nk-tb-col">{{$node['media_category']->name}}</td>
                                                                <td class="nk-tb-col">{{$node['count']}}</td>
                                                                <td class="nk-tb-col">{{$node['views_count']}}</td>
                                                                <td class="nk-tb-col">{{round($node['watch_time'],0)}} min = {{floor($node['watch_time'] / 60)}} hrs</td>
                                                            </tr>
                                                        @endforeach
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                </div><!-- .card-inner -->
                            </div><!-- .nk-ecwg -->
                        </div><!-- .card -->
                    </div><!-- .col -->
                </div>
            </div><!-- .nk-block -->
@endsection