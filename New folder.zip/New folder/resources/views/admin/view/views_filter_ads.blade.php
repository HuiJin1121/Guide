@extends('layouts.backend')

@section('content')

            <script type="text/javascript">
                
                function filterChange(){
                    document.getElementById('select_form').submit();
                }

            </script>

            <div class="nk-block">
                <h4 class="nk-block-title">Filter Ad Analysis</h4>
                <form action="{{ route('views.ads.filter') }}" id="select_form">   
                    <div class="row g-gs">
                        <div class="col-3">
                            <div class="form-group">
                                <label class="form-label" for="filter_p">Time Range</label>
                                <div class="form-control-wrap">
                                    <select class="form-select" id="filter_p" onchange="filterChange()" name="filter_p">
                                        <option value="All History" @if($filter_p == "All History") selected @endif>All History</option>
                                        <option value="Yearly" @if($filter_p == "Yearly") selected @endif>Yearly</option>
                                        <option value="Monthly" @if($filter_p == "Monthly") selected @endif>Monthly</option>
                                        <option value="Weekly" @if($filter_p == "Weekly") selected @endif>Weekly</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="col-3">
                            <div class="form-group">
                                <label class="form-label" for="ad_id">Selection Ad</label>
                                <div class="form-control-wrap">
                                    <select class="form-select" onchange="filterChange()" id="ad_id" name="ad_id">
                                        @foreach($ads as $select_ad)
                                            <option value="{{$select_ad->id}}" @if($ad_id == $select_ad->id) selected @endif>{{$select_ad->name}}</option>
                                        @endforeach
                                    </select>
                                </div>
                            </div>
                        </div>
                    </div>
                </form>
                <div class="row g-gs">
                    <div class="col-xxl-6 col-sm-12">
                    <div class="card" style={height:400px !important;}>
                            <div class="card-aside-wrap">
                                <div class="card-inner card-inner-lg">
                                    <div class="nk-block-head nk-block-head-lg">
                                        <div class="nk-block-between">
                                        <div class="card-title-group">
                                            <div class="card-title">
                                            <h6 class="title">Ad Play Counts</h6>
                                            </div>
                                        </div>
                                        <div class="nk-block-head-content align-self-start d-lg-none">
                                                <a href="#" class="toggle btn btn-icon btn-trigger mt-n1" data-target="userAside"><em class="icon ni ni-menu-alt-r"></em></a>
                                        </div>
                                    </div>
                                </div>
                                    <div class="card card-preview">
                                        <div class="card-inner">
                                            <table class="datatable-init table">
                                                <thead>
                                                    <tr>
                                                        <th>Video</th>
                                                        <th>Plays</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    @foreach($videos as $video)
                                                        @php
                                                            $type = class_basename($video);
                                                            $title = "";
                                                            $count = $video->adsViews->count();
                                                            if($type == "Movie"){
                                                                $title = $video->title;
                                                            }
                                                            else {
                                                                $title = $video->season->title." ".$video->title;
                                                            }
                                                        @endphp
                                                        @if($count != 0)
                                                        <tr>
                                                            <td>{{$title}}</td>
                                                            <td>{{$count}}</td>
                                                        </tr>
                                                        @endif
                                                    @endforeach
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div><!-- .col -->
                    <div class="col-xxl-6 col-sm-12">
                        <div class="card" style={height:400px !important;}>
                            <div class="card-aside-wrap">
                                <div class="card-inner card-inner-lg">
                                    <div class="nk-block-head nk-block-head-lg">
                                        <div class="nk-block-between">
                                        <div class="card-title-group">
                                            <div class="card-title">
                                                <h6 class="title">Ad Play Times</h6>
                                            </div>
                                        </div>
                                        <div class="nk-block-head-content align-self-start d-lg-none">
                                                <a href="#" class="toggle btn btn-icon btn-trigger mt-n1" data-target="userAside"><em class="icon ni ni-menu-alt-r"></em></a>
                                        </div>
                                    </div>
                                </div>
                                    <div class="card card-preview">
                                        <div class="card-inner">
                                            <table class="datatable-init table">
                                                <thead>
                                                    <tr>
                                                        <th>Video</th>
                                                        <th>Date and Time</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    @foreach($videos as $video)
                                                        @php
                                                            $type = class_basename($video);
                                                            $title = "";
                                                            if($type == "Movie"){
                                                                $title = $video->title;
                                                            }
                                                            else {
                                                                $title = $video->season->title." ".$video->title;
                                                            }
                                                        @endphp
                                                        @foreach($video->adsViews as $adView)
                                                            <tr>
                                                                <td>{{$title}}</td>
                                                                <td>{{date_format($adView->created_at,"Y M d h:m:s")}}</td>
                                                            </tr>
                                                        @endforeach
                                                    @endforeach
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div><!-- .col -->
                </div>
            </div><!-- .nk-block -->
@endsection