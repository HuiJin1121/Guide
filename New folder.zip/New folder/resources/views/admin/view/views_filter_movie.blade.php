    @extends('layouts.backend')

@section('content')

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
    <script src="https://code.highcharts.com/highcharts.js"></script>

    <script type="text/javascript">

        document.onready = drawChart;

        function drawChart() {
            drawVideoDetail();
            drawGenderChart();
        }

        function drawVideoDetail(){
            @if($group_views != null)
            var chart = {
                type: 'areaspline'	  
            };
            var title = {
                text: ''   
            }; 
            var subtitle = {
                style: {
                    position: 'absolute',
                    right: '0px',
                    bottom: '10px'
                }
            };
            var legend = {
                enabled : false
            };
            var xAxis = {
                type: 'datetime',
            };
            var yAxis = {
                allowDecimals:false,
                title: {
                    text: null
                }
            };
            var tooltip = {
                shared: true,
                valueSuffix: ' units'
            };
            var credits = {
                enabled: false
            }

            var plotOptions = {
                areaspline: {
                    fillOpacity: 0.5
                },        
                series: {
                        pointStart: Date.UTC(
                            {{$then->year}},
                            {{$then->month - 1}},
                            {{$then->day}},
                        ),
                        pointIntervalUnit: 'day'
                }
            };

            @php
                $len = $now->diffInDays($then);
            @endphp

            let filledArray = Array({{$len + 1}}).fill(0);
            
            @php
                foreach($group_views as $group){
                    $time = \Carbon\Carbon::parse($group->date);
                    $index = $time->diffInDays($then);
                    @endphp
                        filledArray[{{$index}}] = {{$group->views ?? 0}};
                    @php
                }
            @endphp

            var series = [
                {
                    name: 'Views',
                    data: filledArray
                }, 
            ];

            var json = {};
            json.chart = chart; 
            json.title = title;
            json.subtitle = subtitle; 
            json.xAxis = xAxis;
            json.yAxis = yAxis;
            json.legend = legend;
            json.plotOptions = plotOptions;
            json.credits = credits;
            json.series = series;

            Highcharts.chart('viedo_detail_chart',json,null);

            @endif;
        }

        function drawGenderChart(){

            @if($current_views == null)
                return;
            @else
                @php
                    $male_count = 0;
                    $female_count = 0;
                    $other_count = 0;
                    foreach($current_views as $video_view){
                        if($video_view->profile == null) continue;
                        if($video_view->profile->gender == null){
                            $other_count++;
                        }
                        else if ($video_view->profile->gender == "Male" || $video_view->profile->gender == "male"){
                            $male_count++;
                        }
                        else if ($video_view->profile->gender == "Female" || $video_view->profile->gender == "female"){
                            $female_count++;
                        }
                    }
                @endphp

                var genders = [
                    { name : 'Male', count : {{$male_count}} }, 
                    { name : 'Female', count : {{$female_count}} }, 
                    { name : 'Other', count : {{$other_count}} }, 
                ];

                var colors = Highcharts.getOptions().colors;

                var genderData = [];
                var i, j;
                var dataLen = genders.length;
                
                // Build the data arrays
                for (i = 0; i < dataLen; i += 1) {
                // add browser data
                genderData.push(
                    {
                        name: genders[i].name,
                        y: genders[i].count,
                        color: colors[i]
                    });
                }

                var chart = {
                    type: 'pie'
                };
                var title = {
                    text:""
                };      
                var yAxis = {
                    title: {
                        text: 'Total percent'
                    }
                };
                var tooltip = {
                    valueSuffix: ' View'
                };
                var plotOptions = {
                    pie: {
                        allowPointSelect: true,
                        cursor: 'pointer',
                        dataLabels: {
                            enabled: false           
                        },
                        showInLegend: true
                    }
                };

                var credits = {
                    enable : false
                };
                var series = [
                    {
                        name: 'Gender',
                        data: genderData,
                        size:'80%',
                        innerSize: '60%',
                        
                        dataLabels: {
                            formatter: function () {
                                return this.y == 0 ? null : this.point.name;
                            },
                            color: 'white',
                            distance: -30
                        }
                    }, 
                ];
                var legend = {
                    labelFormat: '{name} ({percentage:.1f}%)',
                }     
                
                var json = {};   
                json.chart = chart; 
                json.credits = credits;
                json.yAxis = yAxis;
                json.title = title;        
                json.tooltip = tooltip;
                json.series = series;
                json.plotOptions = plotOptions;

                Highcharts.chart('video_gender_chart',json,null);

            @endif
        }

        function filterChange(){
            document.getElementById('select_form').submit();
        }

    </script>

    <div class="nk-block">
        <h4 class="nk-block-title">Filter Movie Analysis</h4>

        <form action="{{ route('views.movies.filter') }}" id="select_form">   
            <div class="row g-gs">
                <div class="col-3">
                    <div class="form-group">
                        <label class="form-label" for="movie_id">Video Name</label>
                        <div class="form-control-wrap">
                            
                                <select class="form-select" id="movie_id" onchange="filterChange()" name="movie_id">
                                    @foreach($movies as $category_video)
                                        <option value="{{$category_video->id}}" @if($category_video->id == $movie_id) selected @endif>{{$category_video->title}}</option>
                                    @endforeach
                                </select>
                            
                        </div>
                    </div>
                </div>
                <div class="col-3">
                    <div class="form-group">
                        <label class="form-label" for="filter_p">Time Range</label>
                        <div class="form-control-wrap">
                            <select class="form-select" id="filter_p" onchange="filterChange()" name="filter_p">
                                <option value="All History" @if($filter_p == "All History") selected @endif>All History</option>
                                <option value="Yearly" @if($filter_p == "Yearly") selected @endif>Yearly</option>
                                <option value="Monthly" @if($filter_p == "Monthly") selected @endif>Monthly</option>
                                <option value="Weekly" @if($filter_p == "Weekly") selected @endif>Weekly</option>
                            </select>
                        </div>
                    </div>
                </div>
            </div>
        </form>

        @if($movie != null)
        <div class="row g-gs">
            <div class="col-xxl-8 col-sm-12">
                <div class="card">
                    <div class="nk-ecwg nk-ecwg6">
                        <div class="card-inner">
                            <div class="card-title-group">
                                <div class="card-title">
                                    <h6 class="title">Title: {{$movie == null ? "" : $movie->title}}</h6>
                                </div>
                            </div>
                            <div class="data">
                                <div class="data-group">
                                    <div 
                                        class="col-12"
                                        id="viedo_detail_chart"
                                        style="height: 400px;"
                                        ></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-xxl-4 col-sm-12">
                <div class="card">
                    <div class="nk-ecwg nk-ecwg6">
                        <div class="card-inner">
                            <div class="card-title-group">
                                <div class="card-title">
                                    <h6 class="title">Age Groups</h6>
                                </div>
                            </div>
                            <div class="data">
                                <div class="data-group">
                                    <div class="col-xl-12" 
                                        id="age_groups_chart"
                                        style="height: 400px;"
                                        >
                                        <table class="nowrap nk-tb-list is-separate dataTable no-footer" data-auto-responsive="false" id="DataTables_Table_2" role="grid" aria-describedby="DataTables_Table_2_info">
                                            <thead class="d-none">
                                                <tr class="nk-tb-item nk-tb-head" role="row">
                                                    <th class="nk-tb-col sorting" >Group</th>
                                                    <th class="nk-tb-col sorting" >Age</th>
                                                </tr>
                                            </thead>
                                            @if($prev_views == null || $current_views == null)
                                            @else
                                                @php
                                                    $age_groups = array();

                                                    array_push($age_groups,"0-10");
                                                    array_push($age_groups,"11-14");
                                                    array_push($age_groups,"15-21");
                                                    array_push($age_groups,"22-35");
                                                    array_push($age_groups,"36+");

                                                    $current_data = new \stdClass();
                                                    $prev_data = new \stdClass();

                                                    foreach($current_views as $current_view){
                                                        if($current_view->profile == null) continue;
                                                        if($current_view->profile->age == null){

                                                        }       
                                                        else {
                                                            foreach($age_groups as $age_group){
                                                                if(str_contains($current_view->profile->age, $age_group)){
                                                                    if(isset($current_data->$age_group)){
                                                                        $current_data->$age_group++;
                                                                    }
                                                                    else $current_data->$age_group = 1;
                                                                    break;
                                                                }
                                                            }
                                                        }
                                                    }
                                                    
                                                    foreach($prev_views as $current_view){
                                                        if($current_view->profile == null) continue;
                                                        if($current_view->profile->age == null){

                                                        }       
                                                        else {
                                                            foreach($age_groups as $age_group){
                                                                if(str_contains($current_view->profile->age, $age_group)){
                                                                    if(isset($prev_data->$age_group)){
                                                                        $prev_data->$age_group++;
                                                                    }
                                                                    else $prev_data->$age_group = 1;
                                                                    break;
                                                                }
                                                            }
                                                        }
                                                    }

                                                    $age_data = array();

                                                    foreach($age_groups as $age_group){
                                                        $current_count = $current_data->$age_group ?? 0;
                                                        $prev_count = $prev_data->$age_group ?? 0;
                                                        $percent = $prev_count == 0 ? $current_count == 0 ? 0 : 100 : (round($current_count * 100.0 / $prev_count,2) - 100);
                                                        $node = new \stdClass();
                                                        $node->name = $age_group;
                                                        $node->count = $current_count;
                                                        $node->percent = $percent;
                                                        array_push($age_data,$node);
                                                    }

                                                @endphp

                                            <tbody>
                                                @foreach($age_data as $node)
                                                    <tr class="nk-tb-item odd">
                                                        <td class="nk-tb-col"><h4 class="title">{{$node->name}}</h5><td>
                                                        <td class="nk-tb-col">
                                                            <div class="nk-ecwg nk-ecwg6">
                                                                    <div class="card-title-group">
                                                                        <div class="card-title">
                                                                            <h5 class="title">{{$node->count}}</h6>
                                                                        </div>
                                                                    </div>
                                                                    <div class="data">
                                                                        <div class="info">
                                                                            <span class="change
                                                                                            @if($node->percent < 0) text-warning
                                                                                            @else change up text-danger
                                                                                            @endif">
                                                                                <em class="icon ni 
                                                                                            @if($node->percent < 0) ni-arrow-long-down
                                                                                            @else ni-arrow-long-up
                                                                                            @endif">
                                                                                </em>
                                                                                {{$node->percent}}%
                                                                            </span>
                                                                            <span> vs. last month</span>
                                                                        </div>
                                                                    </div>
                                                            </div><!-- .nk-ecwg -->
                                                        </td>
                                                    </tr>
                                                @endforeach
                                            </tbody>
                                            @endif
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div><!-- .card-inner -->
                    </div><!-- .nk-ecwg -->
                </div><!-- .card -->
            </div><!-- .col -->

            <div class="col-xxl-8 col-sm-12">
                <div class="card" style={height:400px !important;}>
                    <div class="card-aside-wrap">
                        <div class="card-inner card-inner-lg">
                            <div class="nk-block-head nk-block-head-lg">
                                <div class="nk-block-between">
                                <div class="card-title-group">
                                    <div class="card-title">
                                        <h6 class="title">Zip Code</h6>
                                    </div>
                                </div>
                                    <div class="nk-block-head-content align-self-start d-lg-none">
                                        <a href="#" class="toggle btn btn-icon btn-trigger mt-n1" data-target="userAside"><em class="icon ni ni-menu-alt-r"></em></a>
                                    </div>
                                </div>
                            </div>
                            <div class="card card-preview">
                                <div class="card-inner">
                                    <table class="datatable-init table">
                                        <thead>
                                            <tr>
                                                <th>Zip Code</th>
                                                <th>Views</th>
                                            </tr>
                                        </thead>
                                        @if($current_views != null)
                                        @php
                                            $a = array();
                                            foreach($current_views as $video_view){
                                                if($video_view->profile == null) continue;
                                                $zip_code = $video_view->profile->zipcode;
                                                if($zip_code == null){

                                                }
                                                else if(isset($a[$zip_code])){
                                                    $a[$zip_code] ++;
                                                }
                                                else {
                                                    $a[$zip_code] = 1;
                                                }
                                            }
                                        @endphp
                                        <tbody>
                                            @foreach($a as $key => $value)    
                                                <tr>
                                                    <td>{{ $key }}</td>
                                                    <td>{{ $value }}</td>
                                                </tr>
                                            @endforeach
                                        </tbody>
                                        @endif
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-xxl-4 col-sm-12">
                <div class="card">
                    <div class="nk-ecwg nk-ecwg6">
                        <div class="card-inner">
                            <div class="card-title-group">
                                <div class="card-title">
                                    <h6 class="title">Gender</h6>
                                </div>
                            </div>
                            <div class="data">
                            <div class="data-group">
                                    <div class="col-xl-12" 
                                        id="video_gender_chart"
                                        style="height: 400px;"
                                        >
                                    </div>
                                </div>
                            </div>
                        </div><!-- .card-inner -->
                    </div><!-- .nk-ecwg -->
                </div><!-- .card -->
            </div><!-- .col -->
        </div>
        @endif
    </div><!-- .nk-block -->
@endsection