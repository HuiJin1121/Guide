@extends('layouts.backend')

@section('content')
            <script>

                function filterChange(){
                    document.getElementById('select_form').submit();
                }

            </script>

            <div class="nk-block">
                <h4 class="nk-block-title">All Contributor Analysis</h4>
                <form action="{{ route('views.contributers.all') }}" id="select_form">   
                    <div class="row g-gs">
                        <div class="col-3">
                            <div class="form-group">
                                <label class="form-label" for="filter_p">Time Range</label>
                                <div class="form-control-wrap">
                                    <select class="form-select" id="filter_p" onchange="filterChange()" name="filter_p">
                                        <option value="All History" @if($filter_p == "All History") selected @endif>All History</option>
                                        <option value="Yearly" @if($filter_p == "Yearly") selected @endif>Yearly</option>
                                        <option value="Monthly" @if($filter_p == "Monthly") selected @endif>Monthly</option>
                                        <option value="Weekly" @if($filter_p == "Weekly") selected @endif>Weekly</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                    </div>
                </form>
                <div class="row g-gs">
                    <div class="col-xxl-12 col-sm-12">
                        <div class="card" style={height:400px !important;}>
                            <div class="card-aside-wrap">
                                <div class="card-inner card-inner-lg">
                                    <div class="nk-block-head nk-block-head-lg">
                                        <div class="nk-block-between">
                                        <div class="card-title-group">
                                            <div class="card-title">
                                            </div>
                                        </div>
                                        <div class="nk-block-head-content align-self-start d-lg-none">
                                                <a href="#" class="toggle btn btn-icon btn-trigger mt-n1" data-target="userAside"><em class="icon ni ni-menu-alt-r"></em></a>
                                        </div>
                                    </div>
                                </div>
                                    <div class="card card-preview">
                                        <div class="card-inner">
                                            <table class="datatable-init table">
                                                <thead>
                                                    <tr>
                                                        <th>Name</th>
                                                        <th>Video Count</th>
                                                        <th>Total Ad Play</th>
                                                        <th>Total Ad Earning</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    @foreach($contributers as $user)
                                                        @php
                                                            $ad_play_sum = 0;
                                                            $earning = 0;
                                                            $video_count = $user->contMovies->count();
                                                            $video_count += $user->contEpisodes->count();
                                                            foreach($user->contMovies as $movie){
                                                                $ad_play_sum += $movie->ads_views_count;
                                                                $earning += $movie->ads_views_sum_cont_price;
                                                            }
                                                            foreach($user->contEpisodes as $episode){
                                                                $ad_play_sum += $episode->ads_views_count;
                                                                $earning += $episode->ads_views_sum_cont_price;
                                                            }
                                                            foreach($user->contShows as $show){
                                                                foreach($show->seasons as $season){
                                                                    $video_count += $season->episodes->count();
                                                                    foreach($season->episodes as $episode){
                                                                        $ad_play_sum += $episode->ads_views_count;
                                                                        $earning += $episode->ads_views_sum_cont_price;
                                                                    }
                                                                }
                                                            }
                                                        @endphp
                                                        <tr>
                                                            <td>{{$user->email}}</td>
                                                            <td>{{$video_count}}</td>
                                                            <td>{{$ad_play_sum}}</td>
                                                            <td>{{convert_to_finance_type($earning)}}</td>
                                                        </tr>
                                                    @endforeach
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div><!-- .col -->
                </div>
            </div><!-- .nk-block -->
@endsection