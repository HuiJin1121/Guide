@extends('layouts.backend')

@section('content')

            <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
            <script src="https://code.highcharts.com/highcharts.js"></script>

            <script type="text/javascript">

                document.onready = drawChart;

                function filterChange(){
                    document.getElementById('select_form').submit();
                }

                function drawChart(){
                    drawAdPercentChart();
                }

                function drawAdPercentChart(){
                        @if($ads == null)
                            return;
                        @else
                            @php
                                $image_count = $ads->filter(function ($value){
                                    return $value->type == "image";
                                })->count();
                                $video_count = $ads->filter(function ($value){
                                    return $value->type == "video";
                                })->count();
                            @endphp
                            
                            var ads = [
                                { name : 'Image', count : {{$image_count}} }, 
                                { name : 'Video', count : {{$video_count}} }, 
                            ];

                            var colors = Highcharts.getOptions().colors;

                            var adData = [];
                            var i, j;
                            var dataLen = ads.length;
                            
                            // Build the data arrays
                            for (i = 0; i < dataLen; i += 1) {
                            // add browser data
                            adData.push(
                                {
                                    name: ads[i].name,
                                    y: ads[i].count,
                                    color: colors[i]
                                });
                            }

                            var chart = {
                                type: 'pie'
                            };
                            var title = {
                                text:""
                            };      
                            var yAxis = {
                                title: {
                                    text: 'Total percent'
                                }
                            };
                            var tooltip = {
                                valueSuffix: ''
                            };
                            var plotOptions = {
                                pie: {
                                    allowPointSelect: true,
                                    cursor: 'pointer',
                                    dataLabels: {
                                        enabled: false           
                                    },
                                    showInLegend: true
                                }
                            };
                            var legend = {
                                labelFormat: '{name} ({percentage:.1f}%)',
                            };
                            var series = [
                                {
                                    name: 'Advertisements',
                                    data: adData,
                                    size:'80%',
                                    innerSize: '60%',
                                    
                                    dataLabels: {
                                        formatter: function () {
                                            return this.y == 0 ? null : this.point.name;
                                        },
                                        color: 'white',
                                        distance: -30
                                    }
                                }, 
                            ];     
                            
                            var json = {};   
                            json.chart = chart; 
                            json.yAxis = yAxis;
                            json.title = title;        
                            json.tooltip = tooltip;  
                            json.series = series;
                            json.legend = legend;
                            json.plotOptions = plotOptions;

                            Highcharts.chart('ad_percent_chart',json,null);
                        @endif
                }

            </script>

            <div class="nk-block">
                <h4 class="nk-block-title">All Ad Analysis</h4>
                <form action="{{ route('views.ads.all') }}" id="select_form">   
                    <div class="row g-gs">
                        <div class="col-3">
                            <div class="form-group">
                                <label class="form-label" for="filter_p">Time Range</label>
                                <div class="form-control-wrap">
                                    <select class="form-select" id="filter_p" onchange="filterChange()" name="filter_p">
                                        <option value="All History" @if($filter_p == "All History") selected @endif>All History</option>
                                        <option value="Yearly" @if($filter_p == "Yearly") selected @endif>Yearly</option>
                                        <option value="Monthly" @if($filter_p == "Monthly") selected @endif>Monthly</option>
                                        <option value="Weekly" @if($filter_p == "Weekly") selected @endif>Weekly</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                    </div>
                </form>
                <div class="row g-gs">
                    <div class="col-xxl-8 col-sm-12">
                        <div class="card" style={height:400px !important;}>
                            <div class="card-aside-wrap">
                                <div class="card-inner card-inner-lg">
                                    <div class="nk-block-head nk-block-head-lg">
                                        <div class="nk-block-between">
                                        <div class="card-title-group">
                                            <div class="card-title">
                                            </div>
                                        </div>
                                        <div class="nk-block-head-content align-self-start d-lg-none">
                                                <a href="#" class="toggle btn btn-icon btn-trigger mt-n1" data-target="userAside"><em class="icon ni ni-menu-alt-r"></em></a>
                                        </div>
                                    </div>
                                </div>
                                    <div class="card card-preview">
                                        <div class="card-inner">
                                            <table class="datatable-init table">
                                                <thead>
                                                    <tr>
                                                        <th>Name</th>
                                                        <th>Plays</th>
                                                        <th>Type</th>
                                                        <th>User</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    @foreach($ads as $ad)
                                                        <tr>
                                                            <td>{{$ad->name}}</td>
                                                            <td>{{$ad->adviews->count()}}</td>
                                                            <td>{{$ad->type}}</td>
                                                            <td>{{$ad->user->email}}</td>
                                                        </tr>
                                                    @endforeach
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-xxl-4 col-sm-12">
                        <div class="card">
                            <div class="nk-ecwg nk-ecwg6">
                                <div class="card-inner">
                                    <div class="card-title-group">
                                        <div class="card-title">
                                            <h6 class="title">Video/Image</h6>
                                        </div>
                                    </div>
                                    <div class="data">
                                    <div class="data-group">
                                            <div class="col-xl-12" 
                                                id="ad_percent_chart"
                                                style="height: 400px;"
                                                >
                                            </div>
                                        </div>
                                    </div>
                                </div><!-- .card-inner -->
                            </div><!-- .nk-ecwg -->
                        </div><!-- .card -->
                    </div><!-- .col -->
                </div>
            </div><!-- .nk-block -->
@endsection