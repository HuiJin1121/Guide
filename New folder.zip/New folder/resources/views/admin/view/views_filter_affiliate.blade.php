@extends('layouts.backend')

@section('content')

    <script type="text/javascript">

        function filterChange(){
            document.getElementById('select_form').submit();
        }
    
    </script>

<div class="nk-block">
    <h4 class="nk-block-title">Filter Affiliates Analysis</h4>
    @php
    @endphp
    <form action="{{ route('views.affiliates.filter') }}" id="select_form">   
        <div class="row g-gs">
            <div class="col-3">
                <div class="form-group">
                    <label class="form-label" for="user_id">Selection User</label>
                    <div class="form-control-wrap">
                        <select class="form-select" onchange="filterChange()" id="user_id" name="user_id">
                            @foreach($affiliates as $select_user)
                                <option value="{{$select_user->id}}" @if($user_id == $select_user->id) selected @endif>{{$select_user->email}}</option>
                            @endforeach
                        </select>
                    </div>
                </div>
            </div>
            <div class="col-3">
                <div class="form-group">
                    <label class="form-label" for="filter_p">Time Range</label>
                    <div class="form-control-wrap">
                        <select class="form-select" id="filter_p" onchange="filterChange()" name="filter_p">
                            <option value="All History" @if($filter_p == "All History") selected @endif>All History</option>
                            <option value="Yearly" @if($filter_p == "Yearly") selected @endif>Yearly</option>
                            <option value="Monthly" @if($filter_p == "Monthly") selected @endif>Monthly</option>
                            <option value="Weekly" @if($filter_p == "Weekly") selected @endif>Weekly</option>
                        </select>
                    </div>
                </div>
            </div>
        </div>
    </form>
    <br/>
    <div class="nk-block">
        <div class="card">
            <div class="card-aside-wrap">
                <div class="card-inner card-inner-lg">
                        <div class="card card-preview">
                            <div class="card-inner">
                                <table class="datatable-init table">
                                    <thead>
                                        <tr>
                                            <th>User</th>
                                            <th>Sign Up Date</th>
                                            <th>Account Status</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                            @php
                                                $users = \App\Models\User::where('ref_by',$user_id)->whereBetween('created_at',[$then,$now])->with([
                                                    'p_subscriptions' => function ($query){
                                                        $query->select('p_subscriptions_user.status','expire_at');
                                                    }])->get();
                                            @endphp
                                            @foreach($users as $user)
                                            <tr>
                                                <td>{{$user->email}}</td>
                                                <td>{{date_format($user->created_at,"Y M d")}}</td>
                                                <td>
                                                    @php
                                                        $status = "No Subscription";
                                                        $clsName = "badge-info";
                                                        if($user->p_subscriptions->count() != 0){
                                                            $isActive = false;
                                                            foreach($user->p_subscriptions as $p_subscription){
                                                                if($p_subscription->status == "active" && $p_subscription->expire_at > \Carbon\Carbon::now()){
                                                                    $isActive = true;
                                                                    break;
                                                                }
                                                            }
                                                            if($isActive){
                                                                $clsName = "badge-success";
                                                                $status = "Active";
                                                            }
                                                            else {
                                                                $clsName = "badge-warning";
                                                                $status = "Cancelled";
                                                            }
                                                        }
                                                    @endphp
                                                    <span class="badge {{$clsName}}">{{$status}}</span>
                                                </td>
                                            </tr>
                                        @endforeach
                                    </tbody>
                                </table>
                            </div>
                        </div>
                </div>
            </div>
        </div>
    </div><!-- .nk-block -->

</div><!-- .nk-block -->
@endsection