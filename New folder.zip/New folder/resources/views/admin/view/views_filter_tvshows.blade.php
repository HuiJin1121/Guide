@extends('layouts.backend')

@section('content')

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
    <script src="https://code.highcharts.com/highcharts.js"></script>
    <script type="text/javascript">
        document.onready = drawChart;

        function filterChange(){
            document.getElementById('select_form').submit();
        }

        function drawChart(){
            @if($tvshow == null)
                return;
            @else
            @foreach($tvshow->seasons as $season)
                @php
                    $male_count = 0;
                    $female_count = 0;
                    $other_count = 0;
                    foreach($season->episodes as $episode){
                        foreach($episode->views as $video_view){
                            if($video_view->profile->gender == null){
                                $other_count++;
                            }
                            else if ($video_view->profile->gender == "Male" || $video_view->profile->gender == "male"){
                                $male_count++;
                            }
                            else if ($video_view->profile->gender == "Female" || $video_view->profile->gender == "female"){
                                $female_count++;
                            }
                        }
                    }
                    @endphp

                    var genders = [
                        { name : 'Male', count : {{$male_count}} }, 
                        { name : 'Female', count : {{$female_count}} }, 
                        { name : 'Other', count : {{$other_count}} }, 
                    ];

                    var colors = Highcharts.getOptions().colors;

                    var genderData = [];
                    var i, j;
                    var dataLen = genders.length;
                    
                    // Build the data arrays
                    for (i = 0; i < dataLen; i += 1) {
                    // add browser data
                    genderData.push(
                        {
                            name: genders[i].name,
                            y: genders[i].count,
                            color: colors[i]
                        });
                    }

                    var chart = {
                        type: 'pie'
                    };
                    var title = {
                        text:""
                    };      
                    var yAxis = {
                        title: {
                            text: 'Total percent'
                        }
                    };
                    var tooltip = {
                        valueSuffix: ' View'
                    };
                    var plotOptions = {
                        pie: {
                            allowPointSelect: true,
                            cursor: 'pointer',
                            dataLabels: {
                                enabled: false           
                            },
                            showInLegend: true
                        }
                    };

                    var credits = {
                        enable : false
                    };
                    var series = [
                        {
                            name: 'Gender',
                            data: genderData,
                            size:'80%',
                            innerSize: '60%',
                            
                            dataLabels: {
                                formatter: function () {
                                    return this.y == 0 ? null : this.point.name;
                                },
                                color: 'white',
                                distance: -30
                            }
                        }, 
                    ];
                    var legend = {
                        labelFormat: '{name} ({percentage:.1f}%)',
                    }     
                    
                    var json = {};   
                    json.chart = chart; 
                    json.credits = credits;
                    json.yAxis = yAxis;
                    json.title = title;        
                    json.tooltip = tooltip;  
                    json.series = series;
                    json.plotOptions = plotOptions;

                    Highcharts.chart('video_gender_chart{{$season->id}}',json,null);

            @endforeach
            @endif
        }

    </script>

    <div class="nk-block">
        <h4 class="nk-block-title">Filter TV Show Analysis</h4>
                    
        <form action="{{ route('views.tvshows.filter') }}" id="select_form">
            <div class="row g-gs">
                <div class="col-3">
                    <div class="form-group">
                        <label class="form-label" for="tvshow_id">TV Show Name</label>
                        <div class="form-control-wrap">
                            <select class="form-select" id="tvshow_id" onchange="filterChange()" name="tvshow_id">
                                @foreach($tvshows as $category_video)
                                    <option value="{{$category_video->id}}" @if($category_video->id == $tvshow_id) selected @endif>{{$category_video->title}}</option>
                                @endforeach
                            </select>
                        </div>
                    </div>
                </div>
                <div class="col-3">
                    <div class="form-group">
                        <label class="form-label" for="filter_p">Time Range</label>
                        <div class="form-control-wrap">
                            <select class="form-select" id="filter_p" onchange="filterChange()" name="filter_p">
                                <option value="All History" @if($filter_p == "All History") selected @endif>All History</option>
                                <option value="Yearly" @if($filter_p == "Yearly") selected @endif>Yearly</option>
                                <option value="Monthly" @if($filter_p == "Monthly") selected @endif>Monthly</option>
                                <option value="Weekly" @if($filter_p == "Weekly") selected @endif>Weekly</option>
                            </select>
                        </div>
                    </div>
                </div>
            </div>
        </form>
        <div class="row g-gs">
            @if($tvshow == null)
            @else
                @php
                    $age_groups = array();

                    array_push($age_groups,"0-10");
                    array_push($age_groups,"11-14");
                    array_push($age_groups,"15-21");
                    array_push($age_groups,"22-35");
                    array_push($age_groups,"36+");
                @endphp
                @foreach($tvshow->seasons as $season)
                    @php
                        if($prev_tvshow == null){
                            $prev_season = null;
                        }
                        else $prev_season = $prev_tvshow->seasons->firstWhere('id',$season->id);
                    @endphp
                    <div class="col-xxl-8 col-sm-12">
                        <div class="card" style={height:400px !important;}>
                            <div class="card-aside-wrap">
                                <div class="card-inner card-inner-lg">
                                    <div class="nk-block-head nk-block-head-lg">
                                        <div class="nk-block-between">
                                        <div class="card-title-group">
                                            <div class="card-title">
                                                <h5 class="title">{{$tvshow->title}}</h6>
                                                <h6 class="title">{{$season->title}}</h6>
                                            </div>
                                        </div>
                                        <div class="nk-block-head-content align-self-start d-lg-none">
                                                <a href="#" class="toggle btn btn-icon btn-trigger mt-n1" data-target="userAside"><em class="icon ni ni-menu-alt-r"></em></a>
                                        </div>
                                    </div>
                                </div>
                                    <div class="card card-preview">
                                        <div class="card-inner">
                                            <table class="datatable-init table">
                                                <thead>
                                                    <tr>
                                                        <th>Episodes Code</th>
                                                        <th>Views</th>
                                                        <th>Male</th>
                                                        <th>Female</th>
                                                        <th>Watch Minutes</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    @foreach($season->episodes as $episode)
                                                        <tr>
                                                            @php
                                                                $male_count = $episode->views->filter(function ($value, $key){
                                                                    return $value->profile->gender == "Male" || $value->profile->gender == "male";  
                                                                })->count();
                                                                $female_count = $episode->views->filter(function ($value, $key){
                                                                    return $value->profile->gender == "Female" || $value->profile->gender == "female";  
                                                                })->count();
                                                                $episode_count = 0;
                                                                $time = $episode->watchtimes_sum_time ?? 0;
                                                                $time = convert_sec_to_min(round($time,0));
                                                                $hour = floor($time / 60);
                                                            @endphp
                                                            <td>{{$episode->title}}</td>
                                                            <td>{{$episode->views->count()}}</td>
                                                            <td>{{$male_count}}</td>
                                                            <td>{{$female_count}}</td>
                                                            <td>{{$time.' min = '.$hour.' hr'}}</td>
                                                        </tr>
                                                    @endforeach
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-xxl-4 col-sm-12">
                        <div class="card">
                            <div class="nk-ecwg nk-ecwg6">
                                <div class="card-inner">
                                    <div class="card-title-group">
                                        <div class="card-title">
                                            <h6 class="title">Age Groups</h6>
                                        </div>
                                    </div>
                                    <div class="data">
                                        <div class="data-group">
                                            <div class="col-xl-12" 
                                                id="age_groups_chart"
                                                style="height: 400px;"
                                                >
                                                <table class="nowrap nk-tb-list is-separate dataTable no-footer" data-auto-responsive="false" id="DataTables_Table_2" role="grid" aria-describedby="DataTables_Table_2_info">
                                                    <thead class="d-none">
                                                        <tr class="nk-tb-item nk-tb-head" role="row">
                                                            <th class="nk-tb-col sorting" >Group</th>
                                                            <th class="nk-tb-col sorting" >Age</th>
                                                        </tr>
                                                    </thead>
                                                    @if($season == null)
                                                    @else
                                                        @php
                                                            $current_data = new \stdClass();
                                                            $prev_data = new \stdClass();

                                                            foreach($season->episodes as $episode){
                                                                foreach($episode->views as $current_view){
                                                                    if($current_view->profile->age == null){

                                                                    }       
                                                                    else {
                                                                        foreach($age_groups as $age_group){
                                                                            if(str_contains($current_view->profile->age, $age_group)){
                                                                                if(isset($current_data->$age_group)){
                                                                                    $current_data->$age_group++;
                                                                                }
                                                                                else $current_data->$age_group = 1;
                                                                                break;
                                                                            }
                                                                        }
                                                                    }
                                                                }
                                                            }

                                                            if($prev_season != null)
                                                            foreach($prev_season->episodes as $episode){
                                                                foreach($episode->views as $current_view){
                                                                    if($current_view->profile->age == null){

                                                                    }       
                                                                    else {
                                                                        foreach($age_groups as $age_group){
                                                                            if(str_contains($current_view->profile->age, $age_group)){
                                                                                if(isset($prev_data->$age_group)){
                                                                                    $prev_data->$age_group++;
                                                                                }
                                                                                else $prev_data->$age_group = 1;
                                                                                break;
                                                                            }
                                                                        }
                                                                    }
                                                                }
                                                            }

                                                            $age_data = array();

                                                            foreach($age_groups as $age_group){
                                                                $current_count = $current_data->$age_group ?? 0;
                                                                $prev_count = $prev_data->$age_group ?? 0;
                                                                $percent = $prev_count == 0 ? $current_count == 0 ? 0 : 100 : (round($current_count * 100.0 / $prev_count,2) - 100);
                                                                $node = new \stdClass();
                                                                $node->name = $age_group;
                                                                $node->count = $current_count;
                                                                $node->percent = $percent;
                                                                array_push($age_data,$node);
                                                            }

                                                        @endphp

                                                        <tbody>
                                                            @foreach($age_data as $node)
                                                                <tr class="nk-tb-item odd">
                                                                    <td class="nk-tb-col"><h4 class="title">{{$node->name}}</h5><td>
                                                                    <td class="nk-tb-col">
                                                                        <div class="nk-ecwg nk-ecwg6">
                                                                                <div class="card-title-group">
                                                                                    <div class="card-title">
                                                                                        <h5 class="title">{{$node->count}}</h6>
                                                                                    </div>
                                                                                </div>
                                                                                <div class="data">
                                                                                    <div class="info">
                                                                                        <span class="change
                                                                                                        @if($node->percent < 0) text-warning
                                                                                                        @else change up text-danger
                                                                                                        @endif">
                                                                                            <em class="icon ni 
                                                                                                        @if($node->percent < 0) ni-arrow-long-down
                                                                                                        @else ni-arrow-long-up
                                                                                                        @endif">
                                                                                            </em>
                                                                                            {{$node->percent}}%
                                                                                        </span>
                                                                                        <span> vs. last month</span>
                                                                                    </div>
                                                                                </div>
                                                                        </div><!-- .nk-ecwg -->
                                                                    </td>
                                                                </tr>
                                                            @endforeach
                                                        </tbody>
                                                    @endif
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                </div><!-- .card-inner -->
                            </div><!-- .nk-ecwg -->
                        </div><!-- .card -->
                    </div><!-- .col -->

                    <div class="col-xxl-8 col-sm-12">
                        <div class="card" style={height:400px !important;}>
                            <div class="card-aside-wrap">
                                <div class="card-inner card-inner-lg">
                                    <div class="nk-block-head nk-block-head-lg">
                                        <div class="nk-block-between">
                                        <div class="card-title-group">
                                            <div class="card-title">
                                                <h6 class="title">Zip Code</h6>
                                            </div>
                                        </div>
                                            <div class="nk-block-head-content align-self-start d-lg-none">
                                                <a href="#" class="toggle btn btn-icon btn-trigger mt-n1" data-target="userAside"><em class="icon ni ni-menu-alt-r"></em></a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="card card-preview">
                                        <div class="card-inner">
                                            <table class="datatable-init table">
                                                <thead>
                                                    <tr>
                                                        <th>Zip Code</th>
                                                        <th>Views</th>
                                                    </tr>
                                                </thead>
                                                @php
                                                    $a = array();
                                                    foreach($season->episodes as $episode){
                                                        foreach($episode->views as $video_view){
                                                            $zip_code = $video_view->profile->zipcode;
                                                            if($zip_code== null){

                                                            }
                                                            else if(isset($a[$zip_code])){
                                                                $a[$zip_code] ++;
                                                            }
                                                            else {
                                                                $a[$zip_code] = 1;
                                                            }
                                                        }
                                                    }
                                                @endphp
                                                <tbody>
                                                    @foreach($a as $key => $value)    
                                                        <tr>
                                                            <td>{{ $key }}</td>
                                                            <td>{{ $value }}</td>
                                                        </tr>
                                                    @endforeach
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-xxl-4 col-sm-12">
                        <div class="card">
                            <div class="nk-ecwg nk-ecwg6">
                                <div class="card-inner">
                                    <div class="card-title-group">
                                        <div class="card-title">
                                            <h6 class="title">Gender</h6>
                                        </div>
                                    </div>
                                    <div class="data">
                                    <div class="data-group">
                                            <div class="col-xl-12" 
                                                id="video_gender_chart{{$season->id}}"
                                                style="height: 400px;"
                                                >
                                            </div>
                                        </div>
                                    </div>
                                </div><!-- .card-inner -->
                            </div><!-- .nk-ecwg -->
                        </div><!-- .card -->
                    </div><!-- .col -->
                @endforeach
            @endif
        </div>
    </div><!-- .nk-block -->
@endsection