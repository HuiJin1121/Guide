@extends('layouts.backend')

@section('content')

<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>

    <script type="text/javascript">

        function filterChange(){
            var form_element = document.getElementById('user_video_form');
            form_element.submit();
        }

    </script>

<div class="nk-block">
    <h4 class="nk-block-title">User Analysis</h4>
    <form id="user_video_form" action="{{route('views.users.all')}}"> 
    <div class="row g-gs">
        <div class="col-3">
            <div class="form-group">
                <label class="form-label" for="category">Selection Category</label>
                <div class="form-control-wrap">
                    <select class="form-select" onchange="filterChange()" id="category" name="category">
                        <option value="Movie" @if($category == "Movie") selected @endif>Movie</option>
                        <option value="Show" @if($category == "Show") selected @endif>TV Show</option>
                    </select>
                </div>
            </div>
        </div>
        <div class="col-3">
            <div class="form-group">
                <label class="form-label" for="user_id">Selection User</label>
                <div class="form-control-wrap">
                    <select class="form-select" onchange="filterChange()" id="user_id" name="user_id">
                        @foreach($users as $select_user)
                            <option value="{{$select_user->id}}" @if($user_id == $select_user->id) selected @endif>{{$select_user->email}}</option>
                        @endforeach
                    </select>
                </div>
            </div>
        </div>
        <div class="col-3">
            <div class="form-group">
                <label class="form-label" for="filter_p">Time Range</label>
                <div class="form-control-wrap">
                    <select class="form-select" id="filter_p" onchange="filterChange()" name="filter_p">
                        <option value="All History" @if($filter_p == "All History") selected @endif>All History</option>
                        <option value="Yearly" @if($filter_p == "Yearly") selected @endif>Yearly</option>
                        <option value="Monthly" @if($filter_p == "Monthly") selected @endif>Monthly</option>
                        <option value="Weekly" @if($filter_p == "Weekly") selected @endif>Weekly</option>
                    </select>
                </div>
            </div>
        </div>
    </div>
    <br/>
    <div class="nk-block">
        <div class="card">
            <div class="card-aside-wrap">
                <div class="card-inner card-inner-lg">
                        <div class="card card-preview">
                            <div class="card-inner">
                            <table class="datatable-init table">
                                    <thead>
                                        <tr>
                                            <th>Title</th>
                                            <th>Views</th>
                                            <th>Male</th>
                                            <th>Female</th>
                                            <th>Watch Minutes</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        @foreach($videos as $video)
                                            
                                                @php
                                                    $time = 0;
                                                    $hour = 0;
                                                    $view_count = 0;
                                                    $male_count = 0;
                                                    $female_count = 0;
                                                    if($category == "Show"){
                                                        foreach($video->seasons as $season){
                                                            foreach($season->episodes as $episode){
                                                                foreach($episode->views as $view){
                                                                    if($view->profile->gender == "Male")
                                                                        $male_count++;
                                                                    else if($view->profile->gender == "Female")
                                                                        $female_count++;
                                                                    $time += $episode->watchtimes_sum_time == null ? 0 : $episode->watchtimes_sum_time;
                                                                }
                                                                $view_count += $episode->views->count();
                                                            }
                                                        }
                                                    }
                                                    else {
                                                        $view_count = $video->views->count();
                                                        foreach($video->views as $view){
                                                            if($view->profile == null) continue;
                                                            if($view->profile->gender == "Male")
                                                                $male_count++;
                                                            else if($view->profile->gender == "Female")
                                                                $female_count++;
                                                        }
                                                        $time = $video->watchtimes_sum_time == null ? 0 : $video->watchtimes_sum_time;
                                                    }
                                                    
                                                    $time = convert_sec_to_min($time);
                                                    $hour = floor($time / 60);
                                                @endphp
                                                @if($view_count > 0)
                                                    <tr>
                                                        <td>{{$video->title}}</td>
                                                        <td>{{$view_count}}</td>
                                                        <td>{{$male_count}}</td>
                                                        <td>{{$female_count}}</td>
                                                        <td>{{$time.' min = '.$hour.' hr'}}</td>
                                                    </tr>
                                                @endif
                                        @endforeach
                                    </tbody>
                                </table>
                            </div>
                        </div>
                </div>
            </div>
        </div>
    </div><!-- .nk-block -->
</div><!-- .nk-block -->
@endsection