@extends('layouts.front')

@section('content')

    <div class="flq-background py-7">
        <div class="flq-background-ticker">
            <div class="flq-image-ticker mb-3" data-gap=20 data-pixels-per-second=20>
                <div class="flq-image-ticker-inner">

                </div>
            </div>
        </div>
        <div class="flq-background-overlay" style="background-color: hsla(var(--flq-color-black), 0.8);"></div>
        <div class="container text-center" data-sr="banner-text" data-sr-interval="100" data-sr-distance="10" data-sr-duration="1000">
            <h1 class="display-5 mb-1" data-sr-item="banner-text">Networks</h1>
            <nav aria-label="breadcrumb" data-sr-item="banner-text">
                <ol class="breadcrumb flq-color-opacity">
                    <li class="breadcrumb-item"><a href="{{url('/')}}">Home</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Networks</li>
                </ol>
            </nav>
        </div>
    </div>
    <div class="content-wrap">
        <div class="py-7">
            <div class="mb-3">
                <form action="{{route('networks')}}" method="GET">
                    <div class="row justify-content-center">
                        <div class="col-6">
                            <div class="rowalign-items-center">
                                @php
                                    $search_word = request()->query('name') ?? "";
                                @endphp
                                <div class="col-12 col-sm">
                                    <input class="form-control" type="text" id="name" name="name" value="{{$search_word}}" placeholder="Search Network Name">
                                </div>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
            <div class="container flq-isotope">
                <div class="row gy-4 justify-content-center flq-isotope-grid" data-isotope-layout="fitRows" data-sr="movies-item" data-sr-interval="80" data-sr-duration="1000" data-sr-distance="10">
                    @foreach($networks as $network)
                        @php
                            $count = $network->user->contMovies->count();
                            $count += $network->user->contEpisodes->count();
                            foreach($network->user->contShows as $show){
                                $count += $show->seasons_count;
                            }
                        @endphp
                        <div class="col-12 col-lg-6 col-xl-4 flq-isotope-item">
                            <a href="{{route('networks.show', $network->id)}}">
                                <div data-sr-item="movies-item">
                                    <div class="container mb-1 d-inline-flex" data-sr-item="new-releases">
                                        <img src="{{$network->getFirstMediaUrl('logo')}}" alt="" style="width: 40px;height: 40px;border-radius: 100%;">
                                        <h2 class="ms-2">{{$network->name." "."(".$count.")"}}</h2>
                                    </div>
                                </div>
                            </a>
                        </div>
                    @endforeach
                </div>
            </div>
            @if(!$networks->count())
                <div class="mt-2 mb-2">
                    <div class="row justify-content-center">
                        <div class="col-6">
                            <div>
                                <div class="col-12 col-sm">
                                    <h2 class="text-center">
                                        No Network
                                    </h2>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            @endif
        </div>

    </div>

@endsection

@section('script')
    <script>
        $(document).ready(function() {
            var $grid = $('.flq-isotope-grid').isotope({
                itemSelector: '.flq-isotope-item',
                layoutMode: 'fitRows'
            });

            $('.flq-isotope-options').on('click', 'a', function(event) {
                event.preventDefault();
                var filterValue = $(this).attr('data-filter');
                if (filterValue === 'all') {
                    filterValue = '*';
                }
                $grid.isotope({ filter: filterValue });

                $('.flq-isotope-options a').removeClass('active');
                $(this).addClass('active');
            });
        });
    </script>
@endsection