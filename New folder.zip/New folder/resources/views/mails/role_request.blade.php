<h1>Role Request Received</h1>
<div>
{{$email}}
</div>
<div>
{{ $name }}, I`d like  to have an account as < {{ $role }} >. ({{ $role }})
</div>
<div>
{{$note}}
</div>
@php
    $user_id = \Auth::user()->id;
@endphp
<a>{{route('user.detail', $user_id)."/?role=".$role}}</a>
