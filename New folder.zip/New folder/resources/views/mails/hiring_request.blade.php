<h1>Hiring Request Received</h1>
<br>
<b>Name:</b> {{$name}}<br>
<b>Phone:</b> {{$phone}}<br>
<b>Email:</b> {{$email}}<br>

<b>Message:</b> {{$hire_message}}<br>
