<h1>New Contact Message Received</h1>
<br>
<b>Name:</b> {{$name}}<br>
<b>Email:</b> {{$email}}<br>
<b>Message:</b> {{$message}}<br>
