<h1>Special Request Received</h1>
<br>
<b>Item Name:</b> {{$item_name}}<br>
<b>Name:</b> {{$name}}<br>
<b>Phone:</b> {{$phone}}<br>
<b>Email:</b> {{$email}}<br>

<b>Message:</b> {{$special_request}}<br>
