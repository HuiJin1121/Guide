@extends('layouts.front')
@section('content')
    <div class="flq-swiper-wrapper flq-background">
        <div class="
            flq-background-overlay
            py-6
            d-flex
            align-items-end align-items-md-center
            z-index-2
            ">
            <div class="
                container
                d-flex
                justify-content-center justify-content-md-end
                flq-pe-none
            ">
                <div class="
                    flq-swiper-pagination
                    flq-swiper-pagination-horizontal
                    flq-swiper-pagination-md-vertical
                    flq-pe-initial
                    "></div>
            </div>
        </div>
        <div class="swiper flq-swiper-main" data-parallax=true data-auto-height=true data-speed=600 data-pagination=true data-autoplay='5000'>
            <div class="swiper-container">
                <div class="swiper-wrapper">
                    @foreach($top_scroll_movies as $movie) 
                    <div class="swiper-slide flq-background">
                        <div class="flq-background-image">
                                <span class="flq-image swiper-image" data-speed=0.7 data-swiper-parallax-x=40%>
                                    <img src="{{$movie->getFirstMediaUrl('top_scroll_poster')}}" alt="">
                                </span>
                        </div>
                        <div class="flq-background-overlay" style="background-color: hsla(var(--flq-color-black), 0.4)"></div>
                        <div class="container py-7 min-vh-100 d-flex align-items-center">
                            <div class="row" style="width: 100%;">
                                <div class="col-12 col-md-10 col-lg-8 col-xl-6 pt-navbar flq-vertical-rhythm">
                                    @foreach($movie->genres as $genre)
                                        <div class="flq-subtitle badge badge-white badge-glass badge-translucent" data-animejs> {{$genre->name}} </div>
                                    @endforeach
                                    <h2 class="display-5 mb-0" data-animejs>{{$movie->title}}</h2>
                                        <div class="flq-meta flq-color-opacity mt-3">
                                            <ul class="gx-4">
                                                <!-- <li data-animejs>
                                                    <svg width="43" height="22" viewBox="0 0 43 22" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                        <path d="M43 1.89083C42.8833 0.922265 42.1751 0.150295 41.2733 0C37.3203 0 5.69694 0 1.74393 0C0.756052 0.164717 0 1.07484 0 2.17169C0 3.935 0 18.0384 0 19.801C0 21.0155 0.925061 22 2.06699 22C5.95494 22 37.0623 22 40.9502 22C42.0017 22 42.8699 21.1643 43 20.0826C43 16.4444 43 3.70955 43 1.89083Z" fill="#F6C700" />
                                                        <path fill-rule="evenodd" clip-rule="evenodd" d="M34.2105 15.7931C34.4184 15.7931 34.6936 15.7074 34.7565 15.5381C34.7983 15.425 34.8297 15.0174 34.8514 14.3152V10.8987C34.8514 10.3347 34.8155 9.96654 34.7445 9.79423C34.6727 9.62193 34.3938 9.53615 34.1859 9.53615C33.9825 9.53615 33.8508 9.61206 33.791 9.76159C33.7304 9.91265 33.7005 10.2914 33.7005 10.8987V14.4223C33.7005 15.0083 33.7342 15.3825 33.803 15.5464C33.8718 15.7112 34.0071 15.7931 34.2105 15.7931ZM33.4852 17.5504H30.4131V4.21738H33.7005V8.55468C33.9727 8.23511 34.2764 7.99676 34.6106 7.83964C34.9457 7.68251 35.4482 7.60281 35.8408 7.60281C36.2925 7.60281 36.6844 7.67416 37.0164 7.81687C37.3484 7.95957 37.6019 8.1592 37.7762 8.41653C37.9504 8.67385 38.0551 8.9251 38.0903 9.1718C38.1254 9.4185 38.1434 9.94377 38.1434 10.7484V14.4891C38.1434 15.2891 38.0903 15.8842 37.9841 16.2759C37.8779 16.6668 37.6281 17.0069 37.2363 17.2938C36.8436 17.5815 36.3785 17.725 35.8393 17.725C35.4519 17.725 34.9516 17.6399 34.6174 17.4691C34.2816 17.2991 33.9757 17.0426 33.6975 16.701C33.6953 16.7098 33.6918 16.724 33.6869 16.7436C33.6602 16.8508 33.5933 17.1197 33.4852 17.5504ZM14.911 9.62588L15.0461 10.5624L15.8366 4.3335H20.2944V17.6665H17.315L17.3038 8.667L16.111 17.6665H13.982L12.7241 8.86284L12.7137 17.6665H9.72461V4.3335H14.1487C14.2789 5.14114 14.415 6.0877 14.5578 7.17544C14.5846 7.36349 14.7025 8.1806 14.911 9.62588ZM8.59885 4.42081H5.18652V17.7538H8.59885V4.42081ZM25.9279 7.10712C25.9653 7.27715 25.9847 7.66276 25.9847 8.26546V13.4347C25.9847 14.322 25.9279 14.8655 25.815 15.0659C25.7013 15.2663 25.3992 15.3658 24.9093 15.3658V6.61373C25.281 6.61373 25.5345 6.65396 25.6691 6.7329C25.8037 6.8126 25.8905 6.93709 25.9279 7.10712ZM27.4691 17.5306C27.8752 17.4403 28.2162 17.2809 28.4929 17.0539C28.7689 16.8262 28.9626 16.5112 29.0732 16.1081C29.1847 15.7058 29.2505 14.9065 29.2505 13.711V9.02908C29.2505 7.76751 29.2019 6.92191 29.1263 6.49228C29.0501 6.06189 28.8609 5.67097 28.558 5.32028C28.2544 4.96959 27.8117 4.71758 27.2298 4.56425C26.6473 4.41092 25.6975 4.3335 24.0456 4.3335H21.5V17.6665H25.634C26.5867 17.6361 27.1984 17.5913 27.4691 17.5306Z" fill="black" />
                                                    </svg>
                                                    <strong class="ms-1 flq-color-title">8.4</strong>
                                                </li>
                                                <li data-animejs>
                                                    <a href="#">{{$movie->year}}</a>
                                                </li> -->
                                            </ul>
                                        </div>
                                    <p class="lead" data-animejs> {{$movie->description}} </p>
                                    <div>
                                        <div class="row gy-1">
                                            <!-- <div class="col-auto" data-animejs>
                                                <a href="single-actor.html" class="btn btn-link">Arline Kelley</a>
                                            </div>
                                            <div class="col-auto" data-animejs>
                                                <a href="single-actor.html" class="btn btn-link">Julius Barnett</a>
                                            </div>
                                            <div class="col-auto" data-animejs>
                                                <a href="single-actor.html" class="btn btn-link">Anthony Lindsey</a>
                                            </div> -->
                                        </div>
                                    </div>
                                    <div class="py-1">
                                        <div class="row gy-4 align-items-center">
                                            <div class="col-auto" data-animejs>
                                                <a href="{{route('watch_movie', $movie->id)}}" class="btn btn-icon-sm">
                                                    <span class="btn-name">Watch Now</span>
                                                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                        <path d="M8 19L19 12L8 5V19Z" fill="currentColor" />
                                                    </svg>
                                                </a>
                                            </div>
                                            <div class="col-auto" data-animejs>
                                                <a href="{{route('movie', $movie->id)}}" class="btn btn-link">More Details</a>
                                            </div>
                                        </div>
                                    </div>
                                    <div>
                                        <span class="badge badge-white badge-translucent badge-glass flq-color-title" data-animejs>18+</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    @endforeach
                    @foreach($top_scroll_shows as $show)
                        <div class="swiper-slide flq-background">
                            <div class="flq-background-image">
                        <span class="flq-image swiper-image" data-speed=0.7 data-swiper-parallax-x=40%>
                            <img src="{{$show->getFirstMediaUrl('top_scroll_poster')}}" alt="">
                        </span>
                            </div>
                            <div class="flq-background-overlay" style="background-color: hsla(var(--flq-color-black), 0.4)"></div>
                            <div class="container py-7 min-vh-100 d-flex align-items-center">
                                <div class="row" style="width: 100%;">
                                    <div class="col-12 col-md-10 col-lg-8 col-xl-6 pt-navbar flq-vertical-rhythm">
                                        @foreach($show->genres as $genre)
                                            <div class="flq-subtitle badge badge-white badge-glass badge-translucent" data-animejs> {{$genre->name}} </div>
                                        @endforeach
                                        <h2 class="display-5 mb-0" data-animejs>{{$show->title}}</h2>
                                        <div class="flq-meta flq-color-opacity mt-3">
                                            <ul class="gx-4">
                                                <!-- <li data-animejs>
                                                    <svg width="43" height="22" viewBox="0 0 43 22" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                        <path d="M43 1.89083C42.8833 0.922265 42.1751 0.150295 41.2733 0C37.3203 0 5.69694 0 1.74393 0C0.756052 0.164717 0 1.07484 0 2.17169C0 3.935 0 18.0384 0 19.801C0 21.0155 0.925061 22 2.06699 22C5.95494 22 37.0623 22 40.9502 22C42.0017 22 42.8699 21.1643 43 20.0826C43 16.4444 43 3.70955 43 1.89083Z" fill="#F6C700" />
                                                        <path fill-rule="evenodd" clip-rule="evenodd" d="M34.2105 15.7931C34.4184 15.7931 34.6936 15.7074 34.7565 15.5381C34.7983 15.425 34.8297 15.0174 34.8514 14.3152V10.8987C34.8514 10.3347 34.8155 9.96654 34.7445 9.79423C34.6727 9.62193 34.3938 9.53615 34.1859 9.53615C33.9825 9.53615 33.8508 9.61206 33.791 9.76159C33.7304 9.91265 33.7005 10.2914 33.7005 10.8987V14.4223C33.7005 15.0083 33.7342 15.3825 33.803 15.5464C33.8718 15.7112 34.0071 15.7931 34.2105 15.7931ZM33.4852 17.5504H30.4131V4.21738H33.7005V8.55468C33.9727 8.23511 34.2764 7.99676 34.6106 7.83964C34.9457 7.68251 35.4482 7.60281 35.8408 7.60281C36.2925 7.60281 36.6844 7.67416 37.0164 7.81687C37.3484 7.95957 37.6019 8.1592 37.7762 8.41653C37.9504 8.67385 38.0551 8.9251 38.0903 9.1718C38.1254 9.4185 38.1434 9.94377 38.1434 10.7484V14.4891C38.1434 15.2891 38.0903 15.8842 37.9841 16.2759C37.8779 16.6668 37.6281 17.0069 37.2363 17.2938C36.8436 17.5815 36.3785 17.725 35.8393 17.725C35.4519 17.725 34.9516 17.6399 34.6174 17.4691C34.2816 17.2991 33.9757 17.0426 33.6975 16.701C33.6953 16.7098 33.6918 16.724 33.6869 16.7436C33.6602 16.8508 33.5933 17.1197 33.4852 17.5504ZM14.911 9.62588L15.0461 10.5624L15.8366 4.3335H20.2944V17.6665H17.315L17.3038 8.667L16.111 17.6665H13.982L12.7241 8.86284L12.7137 17.6665H9.72461V4.3335H14.1487C14.2789 5.14114 14.415 6.0877 14.5578 7.17544C14.5846 7.36349 14.7025 8.1806 14.911 9.62588ZM8.59885 4.42081H5.18652V17.7538H8.59885V4.42081ZM25.9279 7.10712C25.9653 7.27715 25.9847 7.66276 25.9847 8.26546V13.4347C25.9847 14.322 25.9279 14.8655 25.815 15.0659C25.7013 15.2663 25.3992 15.3658 24.9093 15.3658V6.61373C25.281 6.61373 25.5345 6.65396 25.6691 6.7329C25.8037 6.8126 25.8905 6.93709 25.9279 7.10712ZM27.4691 17.5306C27.8752 17.4403 28.2162 17.2809 28.4929 17.0539C28.7689 16.8262 28.9626 16.5112 29.0732 16.1081C29.1847 15.7058 29.2505 14.9065 29.2505 13.711V9.02908C29.2505 7.76751 29.2019 6.92191 29.1263 6.49228C29.0501 6.06189 28.8609 5.67097 28.558 5.32028C28.2544 4.96959 27.8117 4.71758 27.2298 4.56425C26.6473 4.41092 25.6975 4.3335 24.0456 4.3335H21.5V17.6665H25.634C26.5867 17.6361 27.1984 17.5913 27.4691 17.5306Z" fill="black" />
                                                    </svg>
                                                    <strong class="ms-1 flq-color-title">8.4</strong>
                                                </li>
                                                <li data-animejs>
                                                    <a href="#">{{$show->year}}</a>
                                                </li> -->
                                            </ul>
                                        </div>
                                        <p class="lead" data-animejs> {{$show->description}} </p>
                                        <div>
                                            <div class="row gy-1">
                                                <!-- <div class="col-auto" data-animejs>
                                                    <a href="single-actor.html" class="btn btn-link">Arline Kelley</a>
                                                </div>
                                                <div class="col-auto" data-animejs>
                                                    <a href="single-actor.html" class="btn btn-link">Julius Barnett</a>
                                                </div>
                                                <div class="col-auto" data-animejs>
                                                    <a href="single-actor.html" class="btn btn-link">Anthony Lindsey</a>
                                                </div> -->
                                            </div>
                                        </div>
                                        <div class="py-1">
                                            <div class="row gy-4 align-items-center">
                                                <div class="col-auto" data-animejs>
                                                    <a href="{{route('show', $show->id)}}" class="btn btn-icon-sm">
                                                        <span class="btn-name">Watch Now</span>
                                                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                            <path d="M8 19L19 12L8 5V19Z" fill="currentColor" />
                                                        </svg>
                                                    </a>
                                                </div>
                                                <div class="col-auto" data-animejs>
                                                    <a href="{{route('show', $show->id)}}" class="btn btn-link">More Details</a>
                                                </div>
                                            </div>
                                        </div>
                                        <div>
                                            <span class="badge badge-white badge-translucent badge-glass flq-color-title" data-animejs>18+</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    @endforeach
                    @foreach($top_scroll_seasons as $season)
                        <div class="swiper-slide flq-background">
                            <div class="flq-background-image">
                        <span class="flq-image swiper-image" data-speed=0.7 data-swiper-parallax-x=40%>
                            <img src="{{$season->getFirstMediaUrl('top_scroll_poster')}}" alt="">
                        </span>
                            </div>
                            <div class="flq-background-overlay" style="background-color: hsla(var(--flq-color-black), 0.4)"></div>
                            <div class="container py-7 min-vh-100 d-flex align-items-center">
                                <div class="row" style="width: 100%;">
                                    <div class="col-12 col-md-10 col-lg-8 col-xl-6 pt-navbar flq-vertical-rhythm">
                                        <h2 class="display-5 mb-0" data-animejs>{{$season->title}}</h2>
                                        <div class="flq-meta flq-color-opacity mt-3">
                                            <ul class="gx-4">
                                                <li data-animejs>
                                                    <a href="#">{{$season->year}}</a>
                                                </li>
                                            </ul>
                                        </div>
                                        <div class="py-1">
                                            <div class="row gy-4 align-items-center">
                                                <div class="col-auto" data-animejs>
                                                    <a href="{{route('season', $season->id)}}" class="btn btn-icon-sm">
                                                        <span class="btn-name">Watch Now</span>
                                                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                            <path d="M8 19L19 12L8 5V19Z" fill="currentColor" />
                                                        </svg>
                                                    </a>
                                                </div>
                                                <div class="col-auto" data-animejs>
                                                    <a href="{{route('season', $season->id)}}" class="btn btn-link">More Details</a>
                                                </div>
                                            </div>
                                        </div>
                                        <div>
                                            <span class="badge badge-white badge-translucent badge-glass flq-color-title" data-animejs>18+</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    @endforeach
                </div>
            </div>
        </div>
    </div>
    <div class="content-wrap">
        @foreach($sections as $section)
            @php
                $section_movies = collect($section->movies);
                $section_seasons = collect($section->seasons);
                $videos = collect();
                $user = Auth::user();
                $profile_id = request()->session()->get('selected_profile');
                if(!empty($user) && $section->id == \App\Models\Section::JUST_FOR_YOU_INDEX) {
                    $videos = $user->getSuggestionVideos($profile_id);
                }
                else if(!empty($user) && $section->id == \App\Models\Section::CONTINUE_WATCHING_INDEX) {
                    $videos = $user->getWatchingVideos($profile_id);
                }
                else {
                    $videos = $section_movies->concat($section_seasons)->sortBy('pivot.order');
                }
            @endphp
            @if($videos->count())
                <div class="flq-swiper-wrapper my-3" data-sr="new-releases" data-sr-interval="100" data-sr-duration="1000" data-sr-distance="10">
                <div class="container mb-1" data-sr-item="new-releases">
                    <h2>{{$section->title}}</h2>
                </div>
                <div class="swiper flq-swiper-effect-touch" data-sr-item=new-releases data-buttons=true data-pagination-custom=true data-gap=30 data-speed=800 data-touch-ratio=0.8 data-slides=1, data-breakpoints=636:2,1072:3,1280:4>
                    <div class="swiper-container container">
                        <div class="swiper-wrapper">
                            @foreach($videos as $video)
                                @if($video instanceof \App\Models\Movie)
                                @php
                                    $movie = $video;
                                    $id = "trailer_movie".$movie->id;
                                @endphp
                                <div class="swiper-slide">
                                    <div class="card flq-card-image flq-card-trailer" onmouseout="onMouseOut()" onmouseover="onHoverItem('{{$id}}')">
                                        <a href="{{$movie->trailer}}" id="{{$id}}" class="d-none" data-fancybox></a>
                                        <a href="{{route('movie',$movie->id)}}" class="card-image fancy-hover">
                                            <span class="flq-image flq-rounded-xl flq-responsive flq-responsive-sm-4x3">
                                                <img src="{{$video->getFirstMediaUrl('thumbnail')}}" alt="">
                                            </span>
                                            <svg width="42" height="42" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path d="M8 19L19 12L8 5V19Z" fill="currentColor" />
                                            </svg>
                                        </a>
                                    </div>
                                    <div class="card-body mt-2">
                                            <h5 class="card-title"><a href="{{route('movie', $video->id)}}">{{get_video_title($video)}}</a></h5>
                                            <div class="flq-meta flq-meta-sm">
                                                <ul>
                                                    <li>
                                                        <a href="" class="card-year">{{$video->year}}</a>
                                                    </li>
                                                    @foreach(get_video_genres($video) as $genre)
                                                        <li>
                                                            <a href="#" class="card-category">{{$genre->name}}</a>
                                                        </li>
                                                    @endforeach
                                                </ul>
                                            </div>
                                    </div>
                                </div>
                                @elseif($video instanceof \App\Models\Episode)
                                    @php
                                        $season = $video->season;
                                        $id = "trailer_episode".$video->id;
                                    @endphp
                                    <div class="swiper-slide">
                                        <div class="card flq-card-image flq-card-sm" onmouseout="onMouseOut()" onmouseover="onHoverItem('{{$id}}')">
                                            <a href="{{$video->trailer}}" id="{{$id}}" class="d-none" data-fancybox></a>
                                            <a href="{{route('season',$season->id)}}" class="card-image fancy-hover">
                                                <span class="flq-image flq-rounded-xl flq-responsive flq-responsive-sm-4x3">
                                                    <img src="{{$video->getFirstMediaUrl('thumbnail')}}" alt="">
                                                </span>
                                                <svg width="42" height="42" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M8 19L19 12L8 5V19Z" fill="currentColor" />
                                                </svg>
                                            </a>
                                            
                                        </div>
                                        <div class="card-body mt-2">
                                                <h5 class="card-title"><a href="{{route('season', $season->id)}}">{{get_video_title($video)}}</a></h5>
                                                <div class="flq-meta flq-meta-sm">
                                                    <ul>
                                                        <li>
                                                            <a href="" class="card-year">{{$video->year}}</a>
                                                        </li>
                                                        @foreach(get_video_genres($video) as $genre)
                                                            <li>
                                                                <a href="#" class="card-category">{{$genre->name}}</a>
                                                            </li>
                                                        @endforeach
                                                    </ul>
                                                </div>
                                        </div>
                                    </div>
                                    @elseif($video instanceof \App\Models\Season)
                                    @php
                                        $id = "trailer_season".$video->id;
                                        $season = $video;
                                    @endphp
                                    <div class="swiper-slide">
                                        <div class="card flq-card-image flq-card-sm" onmouseout="onMouseOut()" onmouseover="onHoverItem('{{$id}}')">
                                            <a href="{{$video->trailer}}" id="{{$id}}" class="d-none" data-fancybox></a>
                                            <a href="{{route('season',$season->id)}}" class="card-image fancy-hover">
                                                <span class="flq-image flq-rounded-xl flq-responsive flq-responsive-sm-4x3">
                                                    <img src="{{$video->getFirstMediaUrl('thumbnail')}}" alt="">
                                                </span>
                                                <svg width="42" height="42" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M8 19L19 12L8 5V19Z" fill="currentColor" />
                                                </svg>
                                            </a>
                                        </div>
                                        <div class="card-body mt-2">
                                                <h5 class="card-title"><a href="{{get_video_route($video)}}">{{get_video_title($video)}}</a></h5>
                                                <div class="flq-meta flq-meta-sm">
                                                    <ul>
                                                        <li>
                                                            <a href="" class="card-year">{{$video->year}}</a>
                                                        </li>
                                                        @foreach(get_video_genres($video) as $genre)
                                                            <li>
                                                                <a href="#" class="card-category">{{$genre->name}}</a>
                                                            </li>
                                                        @endforeach
                                                    </ul>
                                                </div>
                                        </div>
                                    </div>
                                @endif
                            @endforeach
                        </div>
                    </div>
                </div>
                <div class="container mt-1">
                    <div class="row align-items-center justify-content-between gx-5">
                        <div class="col-auto" data-sr-item="new-releases">
                            <div class="flq-swiper-pagination-custom"></div>
                        </div>
                        <div class="col d-none d-sm-block" data-sr-item="new-releases">
                            <hr />
                        </div>
                        <div class="col-auto" data-sr-item="new-releases">
                            <div class="
                                    flq-swiper-button-prev
                                    btn btn-sm btn-dark btn-active btn-square btn-icon-sm
                                    me-1
                                " data-sr-item="related">
                                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M15 18L9 12L15 6" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                                </svg>
                            </div>
                            <div class="
                                flq-swiper-button-next
                                btn btn-sm btn-dark btn-active btn-square btn-icon-sm
                            " data-sr-item="related">
                                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M9 6L15 12L9 18" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                                </svg>
                            </div>
                        </div>
                    </div>
                </div>
                </div>
            @endif
        @endforeach
    </div>
    <script>
        var timeout = null;
        function onHoverItem(id) {
            clearTimeout(timeout);
            timeout = setTimeout(() => {
                var element = document.getElementById(id);
                element.click();
            }, 1000)
        }

        function onMouseOut(){
            clearTimeout(timeout);
        }
    </script>
@endsection

