@extends('layouts.front')
@section('content')

    <div class="py-7 flq-background-color-100">
        <div class="container pt-navbar">
            <h1 class="display-3 mb-0">About Us</h1>
        </div>
    </div>
    <div class="content-wrap">
        <div class="container py-7">
            <p>Notis Studios is an independent film company out of Oklahoma City with a unique style of filmmaking and music production. This company is made up of 5 individuals that have brought their talents together to create interesting pieces of entertainment for the masses. Our goal is to continue to grow in our craft and release features, shorts, and micro-shorts &amp; original soundtracks as often as possible, adding to the wealth of diverse films released each year.&nbsp; For more information please visit&nbsp;<a href=\"http://www.notisstudios.com/\" target=\"_blank\" rel=\"nofollow noopener noreferrer\">www.notisstudios.com</a>&nbsp;or email us @&nbsp;<a href=\"mailto:notisstudios405@gmail.com\" target=\"_blank\" rel=\"nofollow noopener noreferrer\">notisstudios405@gmail.com</a></p>
        </div>
    </div>

@endsection